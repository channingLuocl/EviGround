"""Wait for the two existing phases, then audit one fixed all-source result."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import time

import audit_saved_final_predictions
import audit_source_provenance
import audit_static_inputs

BASE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_bytes())


def main():
    print('Waiting for the existing inference phases and generic-target pair.', flush=True)
    while True:
        states = [read(BASE/name) for name in
            ('r5_top5_retry_state.json', 'r10_top1_retry512_state.json',
             'generic_target_retry4_state.json')]
        if any(s['status'] == 'failed' for s in states):
            raise RuntimeError('An inference phase failed; inspect its original state/log')
        pair_path = BASE/'generic_target_dev39_state.json'
        pair = read(pair_path) if pair_path.exists() else {}
        if pair.get('status') == 'failed':
            raise RuntimeError('The generic-target development pair failed')
        if all(s['status'] == 'phase_completed' for s in states) and pair.get('status') == 'phases_completed':
            break
        time.sleep(10)
    print('Current phases completed. Collecting all 27 sources.', flush=True)
    import update_progress
    update_progress.main()
    raw = (BASE/'progress_cumulative.json').read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    fixed = BASE/'audit_snapshots'/f'{digest}.json'
    if not fixed.exists():
        fixed.write_bytes(raw)
    assert fixed.read_bytes() == raw
    snapshot = json.loads(raw)
    assert len(snapshot['single_pass_runs']) == 27
    assert snapshot['summary']['selected'] == snapshot['summary']['evaluated'] == 7805
    assert not snapshot['summary']['remaining_error_queries']
    print('Checking every saved final prediction in the fixed snapshot.', flush=True)
    audit_saved_final_predictions.main(fixed, BASE/'current_phases_saved_final_audit.json')
    print('Checking preserved source provenance.', flush=True)
    audit_source_provenance.main()
    print('Checking original export, static category tables and scene assets.', flush=True)
    audit_static_inputs.main()
    files = ['current_phases_saved_final_audit.json', 'source_provenance_audit.json',
        'static_inputs_audit.json']
    saved, source, inputs = [read(BASE/name) for name in files]
    assert all(r['cumulative_snapshot_sha256'] == digest for r in (saved, source, inputs))
    assert saved['saved_final_consistency_passed']
    assert source['same_correct_count'] and source['same_evaluated_coverage']
    assert not source['correct_queries_depending_only_on_unpreserved_source']
    assert inputs['original_zip_matches_extracted_export']
    assert inputs['independent_rank_only_projection_matches']
    assert inputs['scene_assets_match_recorded_hashes']
    canonical = {r['csv_row']: r for r in read(update_progress.ROOT/'local/validation/nr3d_val_full.json')['rows']}
    rows = {r['csv_row']: r for r in snapshot['results']}
    assert len(rows) == 7805 and set(rows) == set(canonical)
    correct = set()
    for i, row in rows.items():
        assert all(row[k] == canonical[i][k] for k in
            ('scene', 'query', 'target_id', 'easy', 'view_dep'))
        history = snapshot['attempt_history'][str(i)]
        assert row['correct'] == any(a['correct'] for a in history)
        if row['correct']:
            correct.add(i)
    assert len(correct) == snapshot['summary']['correct']
    for name, field, value, total in [('easy', 'easy', True, 3773),
            ('hard', 'easy', False, 4032), ('view_dependent', 'view_dep', True, 2752),
            ('view_independent', 'view_dep', False, 5053)]:
        keys = {i for i, row in canonical.items() if row[field] is value}
        group = snapshot['groups'][name]
        assert group['selected'] == group['evaluated'] == len(keys) == total
        assert group['correct'] == len(keys & correct)
        assert group['accuracy_over_selected'] == group['correct']/total
    assert sum(r['api_attempts'] for r in snapshot['single_pass_runs']) == snapshot['summary']['total_api_attempts']
    assert sum(r['unreported_token_usage_attempts'] for r in snapshot['single_pass_runs']) == snapshot['summary']['unreported_token_usage_attempts']
    report = {'created_at': datetime.now().astimezone().isoformat(),
        'snapshot_sha256': digest, 'snapshot': str(fixed),
        'summary': snapshot['summary'], 'groups': snapshot['groups'],
        'all_27_sources_accounted_for': True,
        'saved_final_attempts_checked': saved['attempts_checked'],
        'saved_final_consistency_passed': True, 'static_input_audit_passed': True,
        'source_verified_score_unchanged': True,
        'early_source_gap_has_no_exclusive_correct_query': True,
        'audit_files_sha256': {n: hashlib.sha256((BASE/n).read_bytes()).hexdigest() for n in files},
        'gt_reference_correct': 5435, 'gap_from_gt_reference': 5435-len(correct),
        'overall_reference_reached': len(correct) >= 5435,
        'evaluation_policy': 'cumulative_ever_correct_evaluation_oracle',
        'deployment_prediction': False, 'not_single_pass_accuracy': True,
        'token_totals_are_lower_bounds': snapshot['summary']['unreported_token_usage_attempts'] > 0,
        'limitations': 'Historical partial runs and failed attempts remain preserved. Early r2 dev24 lacks three exact source modules, but no exclusive correct query depends on it. Geometry/instances remain annotation-derived. Development and evaluation-selected retries are exposed; cumulative result is not a deployable selector.'}
    (BASE/'current_phases_completion_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    main()
