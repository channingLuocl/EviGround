"""Inspect discarded raw proposals, never count them as final grounding results."""
from collections import Counter
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround/local_outputs'


def main():
    report = {}
    for name in ('v74_r8_r3_top1_full_20261020', 'v74_r8_r7_reference_dev50_20261020'):
        raw = (ROOT/name/'results.json').read_bytes()
        results = json.loads(raw)['results']
        nulls = [r for r in results if r['predicted_id'] is None and not r.get('error')]
        reasons, discarded = Counter(), []
        for row in nulls:
            prediction = json.loads((ROOT/name/f"q{row['csv_row']:05d}/prediction.json").read_text())
            reason = prediction.get('scene_evidence', {}).get('reason', 'No scene decision')
            reasons[reason] += 1
            try:
                proposal = json.loads(prediction.get('response', ''))
            except (ValueError, TypeError):
                continue
            if proposal.get('predicted_id') is not None:
                discarded.append({'csv_row': row['csv_row'], 'raw_proposed_id': proposal['predicted_id'],
                    'proposal_would_match_evaluation_only': proposal['predicted_id'] == row['target_id'],
                    'reason': reason, 'counted_as_final_correct': False})
        report[name] = {'snapshot_evaluated': len(results), 'snapshot_csv_rows': [r['csv_row'] for r in results],
            'source_results_sha256': hashlib.sha256(raw).hexdigest(), 'null_without_execution_error': len(nulls),
            'reason_counts': dict(reasons), 'discarded_nonnull_proposals': discarded,
            'potential_matching_proposals': sum(r['proposal_would_match_evaluation_only'] for r in discarded)}
        print(json.dumps({'run': name, 'evaluated': len(results), 'nulls': len(nulls),
            'discarded_nonnull': len(discarded),
            'potential_matching_proposals': report[name]['potential_matching_proposals']}, ensure_ascii=False))
    (BASE/'abstention_validation_audit.json').write_text(json.dumps({
        'note': 'Diagnostic raw responses only; none count toward final or cumulative grounding accuracy.',
        'runs': report}, ensure_ascii=False, indent=2)+'\n')


if __name__ == '__main__':
    main()
