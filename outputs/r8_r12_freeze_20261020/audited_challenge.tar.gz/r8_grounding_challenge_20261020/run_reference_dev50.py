"""Run and audit the isolated raw-reference-context change against saved r3."""
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'
sys.path.insert(0, str(ROOT/'local'))
from run_storage import write_json


def read(path):
    return json.loads(path.read_text())


def state(**fields):
    write_json(BASE/'reference_dev50_state.json',
               {'time': datetime.now().astimezone().isoformat(), 'pid': os.getpid(), **fields})


def main():
    source = BASE/'source_r7'
    hashes = read(source/'SOURCE_MANIFEST.json')['code_sha256']
    if any(hashlib.sha256((source/'local'/n).read_bytes()).hexdigest() != h for n, h in hashes.items()):
        raise RuntimeError('Frozen source changed')
    selection = BASE/'reference_dev50_manifest.json'
    selected = read(selection)
    output = ROOT/'local_outputs/v74_r8_r7_reference_dev50_20261020'
    command = ['bash', str(source/'local/run_local_v9.sh'), '--predictions',
        str(BASE.parent/'r8_grounding_input_20261020/20261020_r8_object_predictions'),
        '--scene-root', str(ROOT/'local_outputs'), '--manifest', str(selection),
        '--category-top-k', '1', '--output', str(output)]
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'SEEGROUND_R8_GROUNDING_REVISION': 'r7',
           'SEEGROUND_WORKERS': '4', 'SEEGROUND_API_CONCURRENCY': '8'}
    log = BASE/'r7_reference_dev50.log'
    with log.open('a') as handle:
        process = subprocess.Popen(command, cwd=source, env=env, stdout=handle, stderr=subprocess.STDOUT)
        state(status='running', child_pid=process.pid, source=str(source),
              output=str(output), log=str(log), shared_api_slots=8)
        print(f'Started r7 reference-context development: PID {process.pid}', flush=True)
        code = process.wait()
    if code:
        raise RuntimeError(f'Run exited {code}; inspect its preserved log')
    result = read(output/'results.json')
    rows = {r['csv_row']: r for r in result['results']}
    if set(rows) != {r['csv_row'] for r in selected['rows']}:
        raise RuntimeError('Not all 50 final evaluations exist')
    if read(output/'manifest.json')['code_sha256'] != hashes:
        raise RuntimeError('Runtime differs from frozen source')
    cases = []
    for index, row in sorted(rows.items()):
        before = read(ROOT/'local_outputs/v74_r8_r3_top1_full_20261020'/f'q{index:05d}/evaluation.json')
        prediction = output/f'q{index:05d}/prediction.json'
        raw_context = False
        if prediction.exists():
            pred = read(prediction)
            if pred['gt_categories_supplied_to_model'] or pred['query_target_id_supplied_to_model']:
                raise RuntimeError('Evaluation labels entered inference')
            if pred['predicted_id'] is not None and pred['predicted_id'] not in pred['category_target_ids']:
                raise RuntimeError('Final ID is outside predicted-category candidates')
            raw_context = any('r7_raw_interior_context.png' in p for p in pred.get('images', []))
        elif not row.get('error'):
            raise RuntimeError('Missing final prediction without an evaluation error')
        if bool(row['correct']) != (row['predicted_id'] == row['target_id'] and not row.get('error')):
            raise RuntimeError('Stored accuracy disagrees with final ID')
        cases.append({'csv_row': index, 'r3_correct': before['correct'], 'r7_correct': row['correct'],
            'r3_id': before['predicted_id'], 'r7_id': row['predicted_id'], 'raw_context_added': raw_context,
            'error': row.get('error'), 'exposed_regression': index in selected['exposed_regression_ids']})
    def group(items):
        return {'queries': len(items), 'r3_correct': sum(r['r3_correct'] for r in items),
                'r7_correct': sum(r['r7_correct'] for r in items),
                'gained': [r['csv_row'] for r in items if not r['r3_correct'] and r['r7_correct']],
                'lost': [r['csv_row'] for r in items if r['r3_correct'] and not r['r7_correct']]}
    report = {'all': group(cases), 'primary48': group([r for r in cases if not r['exposed_regression']]),
        'exposed_regression2': group([r for r in cases if r['exposed_regression']]),
        'raw_context_subset': group([r for r in cases if r['raw_context_added']]),
        'errors': sum(bool(r['error']) for r in cases), 'api_attempts': result['summary']['actual_api_attempts'],
        'cases': cases, 'source_hashes_checked': True, 'inference_label_flags_checked': True,
        'note': 'Targeted development only; model and parser variation may affect unchanged cases. No full improvement claim.'}
    write_json(BASE/'reference_dev50_comparison.json', report)
    state(status='phases_completed', summary={k: v for k, v in report.items() if k != 'cases'},
          promotion_pending=True, goal_achieved=False)
    print(json.dumps({k: v for k, v in report.items() if k != 'cases'}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        state(status='failed', error=str(exc))
        raise
