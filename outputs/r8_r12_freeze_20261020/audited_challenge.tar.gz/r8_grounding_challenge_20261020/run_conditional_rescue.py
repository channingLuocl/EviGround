"""Continue the authorized cumulative experiment only after the baseline phases finish."""
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from zoneinfo import ZoneInfo

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'
sys.path.insert(0, str(ROOT/'local'))
from r8_challenge_results import collect, read
from run_storage import write_json

SELECTION = ROOT/'local/validation/nr3d_val_full.json'
TARGET_CORRECT = 5435
RUN_NAMES = ('v74_r8_top5_full_20261020', 'v74_r8_r2_dev24_20261020',
    'v74_r8_r2_dev48_20261020', 'v74_r8_r3_top1_dev48_20261020',
    'v74_r8_r3_top5_dev48_20261020', 'v74_r8_r3_top1_full_20261020',
    'v74_r8_r3_top5_retry_20261020', 'v74_r8_r4_top1_dev48_20261020',
    'v74_r8_r4_infrastructure_retry_20261020', 'v74_r8_r5_top1_dev48_20261020')


def now():
    return datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()


def status(**fields):
    write_json(BASE/'conditional_rescue_state.json', {'time': now(), 'pid': os.getpid(), **fields})


def wait_for_baseline():
    while True:
        state = read(BASE/'state.json')
        if state['status'] == 'phases_completed':
            return
        if state['status'] == 'failed':
            raise RuntimeError('Baseline runner reported failure; inspect it before retrying')
        # A state file alone is insufficient evidence of a live job.
        command = subprocess.run(['ps', '-p', str(state['pid']), '-o', 'command='],
                                 capture_output=True, text=True)
        if command.returncode or 'run_challenge.py' not in command.stdout:
            raise RuntimeError('Baseline wrapper is no longer live; inspect its child before restarting anything')
        time.sleep(30)


def merge(runs):
    report = collect(read(SELECTION), runs)
    write_json(BASE/'cumulative/results.json', report)
    return report


def choose_revision():
    candidates = []
    for revision in ('r4', 'r5'):
        output = ROOT/'local_outputs'/f'v74_r8_{revision}_top1_dev48_20261020'
        manifest = read(output/'manifest.json')
        result = read(output/'results.json')
        if len(result['results']) != 48 or len(manifest['rows']) != 48:
            raise RuntimeError('Numeric development experiment is incomplete')
        for row in result['results']:
            if row.get('error'):
                continue
            pred = read(output/f"q{row['csv_row']:05d}/prediction.json")
            if pred['gt_categories_supplied_to_model'] or pred['query_target_id_supplied_to_model']:
                raise RuntimeError('Evaluation labels entered a candidate inference run')
        # Predeclared criterion: complete-dev correct count, then fewer errors, then explicit frame IDs.
        key = (result['summary']['correct'], -result['summary'].get('errors', 0), revision == 'r5')
        candidates.append((key, revision, manifest))
    _, revision, manifest = max(candidates, key=lambda c: c[0])
    source = BASE/('source_'+revision)
    expected = read(source/'SOURCE_MANIFEST.json')['code_sha256']
    if manifest['code_sha256'] != expected:
        raise RuntimeError('Selected snapshot differs from its completed development experiment')
    if any(hashlib.sha256((source/'local'/name).read_bytes()).hexdigest() != digest
           for name, digest in expected.items()):
        raise RuntimeError('Selected source changed after development validation')
    return revision, source, {rev: list(key) for key, rev, _ in candidates}


def main():
    status(status='waiting_for_live_baseline', baseline_state=str(BASE/'state.json'))
    print(f'{now()} Waiting for the existing baseline phases; no duplicate inference started.', flush=True)
    wait_for_baseline()
    runs = [ROOT/'local_outputs'/name for name in RUN_NAMES
            if (ROOT/'local_outputs'/name/'manifest.json').exists()]
    first = merge(runs)
    if not first['summary']['complete']:
        raise RuntimeError('Full canonical selection is not evaluated yet')
    if first['summary']['correct'] >= TARGET_CORRECT:
        status(status='not_needed', summary=first['summary'], completion_audit_pending=True)
        return
    revision, source, criteria = choose_revision()
    correct = {r['csv_row'] for r in first['results'] if r['correct']}
    selected = read(SELECTION)
    selected['rows'] = [r for r in selected['rows'] if r['csv_row'] not in correct]
    selected.update(purpose='User-authorized evaluation-guided cumulative rescue after complete baseline phases',
        selection_policy='Remaining canonical queries never correct in prior final outputs',
        candidate_selection='Complete dev48 correct count; fewer errors; explicit frame IDs on ties',
        inference_gt_categories=False, answers_sent_to_workers=False)
    selection_path = BASE/f'{revision}_conditional_rescue_manifest.json'
    write_json(selection_path, selected)
    output = ROOT/'local_outputs'/f'v74_r8_{revision}_conditional_rescue_20261020'
    command = ['bash', str(source/'local/run_local_v9.sh'), '--predictions',
        str(BASE.parent/'r8_grounding_input_20261020/20261020_r8_object_predictions'),
        '--scene-root', str(ROOT/'local_outputs'), '--manifest', str(selection_path),
        '--category-top-k', '1', '--output', str(output)]
    env = {**os.environ, 'SEEGROUND_R8_GROUNDING_REVISION': revision,
           'SEEGROUND_WORKERS': '10', 'SEEGROUND_API_CONCURRENCY': '8'}
    log = BASE/f'{revision}_conditional_rescue.log'
    with log.open('a') as handle:
        process = subprocess.Popen(command, cwd=source, env=env, stdout=handle, stderr=subprocess.STDOUT)
        status(status='running', revision=revision, source=str(source), output=str(output),
               selected=len(selected['rows']), child_pid=process.pid, log=str(log), criteria=criteria)
        print(f'{now()} Started {revision} rescue for {len(selected["rows"])} remaining queries.', flush=True)
        code = process.wait()
    if code:
        raise RuntimeError(f'Conditional rescue exited {code}; inspect {log}')
    if len(read(output/'results.json')['results']) != len(selected['rows']):
        raise RuntimeError('Rescue exited before completing its selection')
    report = merge(runs+[output])
    status(status='phase_completed', revision=revision, summary=report['summary'],
           groups=report['groups'], completion_audit_pending=True, goal_achieved=False)
    print(json.dumps(report['summary'], ensure_ascii=False), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        status(status='failed', error=str(exc))
        raise
