"""Retry the four remaining generic-target failures with validated frozen r12."""
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'
SOURCE = BASE/'source_r12'
OUTPUT = ROOT/'local_outputs/v74_r8_r12_generic_target_retry4_20261020'
STATE = BASE/'generic_target_retry4_state.json'
sys.path.insert(0, str(ROOT/'local'))
from r8_challenge_results import collect, read
from run_storage import write_json
from audit_saved_final_predictions import main as audit_finals


def state(**fields):
    write_json(STATE, {'time': datetime.now().astimezone().isoformat(),
        'pid': os.getpid(), 'output': str(OUTPUT), **fields})


def main():
    selection_path = BASE/'generic_target_retry4_manifest.json'
    selection = read(selection_path)
    assert len(selection['rows']) == 4
    assert read(BASE/'generic_target_dev39_comparison.json')['all_saved_final_predictions_checked']
    hashes = read(SOURCE/'SOURCE_MANIFEST.json')['code_sha256']
    assert all(hashlib.sha256((SOURCE/'local'/n).read_bytes()).hexdigest() == h for n, h in hashes.items())
    shared = (ROOT/'local_outputs/v74_r8_r5_top5_retry_20261020/.api_slots').resolve()
    OUTPUT.mkdir(exist_ok=False)
    (OUTPUT/'.api_slots').symlink_to(shared, target_is_directory=True)
    command = ['bash', str(SOURCE/'local/run_local_v9.sh'), '--predictions',
        str(BASE.parent/'r8_grounding_input_20261020/20261020_r8_object_predictions'),
        '--scene-root', str(ROOT/'local_outputs'), '--manifest', str(selection_path),
        '--category-top-k', '5', '--output', str(OUTPUT)]
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1',
        'SEEGROUND_R8_GROUNDING_REVISION': 'r12',
        'SEEGROUND_WORKERS': '4', 'SEEGROUND_API_CONCURRENCY': '8'}
    with (BASE/'generic_target_retry4.log').open('a') as handle:
        process = subprocess.Popen(command, cwd=SOURCE, env=env,
            stdout=handle, stderr=subprocess.STDOUT)
        state(status='running', child_pid=process.pid, selected=4)
        print(f'Started four-query generic-target rescue, child PID {process.pid}', flush=True)
        code = process.wait()
    if code:
        raise RuntimeError(f'Generic-target rescue exited {code}')
    manifest = read(OUTPUT/'manifest.json')
    assert manifest['rows'] == selection['rows'] and manifest['code_sha256'] == hashes
    assert Path(manifest['api']['api_slot_dir']).resolve() == shared
    report = collect(selection, [OUTPUT])
    assert report['summary']['evaluated'] == 4
    phase = BASE/'generic_target_retry4_phase_results.json'
    write_json(phase, report)
    state(status='auditing_saved_finals', selected=4)
    audit_finals(phase, BASE/'generic_target_retry4_saved_final_audit.json')
    state(status='phase_completed', selected=4, summary=report['summary'],
        all_saved_final_predictions_checked=True, full_denominator_union_pending=True)
    print(json.dumps(report['summary'], ensure_ascii=False), flush=True)


if __name__ == '__main__':
    if OUTPUT.exists() or STATE.exists():
        raise SystemExit('Existing rescue output/state; inspect its original job')
    try:
        main()
    except Exception as exc:
        state(status='failed', error=str(exc))
        raise
