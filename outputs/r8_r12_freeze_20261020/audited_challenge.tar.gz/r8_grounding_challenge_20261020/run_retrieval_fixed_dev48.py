"""Validate matching-only synonyms against the saved r5 Top-5 development baseline."""
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'
sys.path.insert(0, str(ROOT/'local'))
from run_storage import write_json


def read(path):
    return json.loads(path.read_text())


def state(**fields):
    write_json(BASE/'retrieval_fixed_dev48_state.json',
               {'time': datetime.now().astimezone().isoformat(), 'pid': os.getpid(), **fields})


def main():
    state(status='waiting_for_referent_development', revision='r10')
    while read(BASE/'referent_dev48_state.json')['status'] != 'phases_completed':
        if read(BASE/'referent_dev48_state.json')['status'] == 'failed':
            raise RuntimeError('Inspect the existing referent job before launching another experiment')
        time.sleep(10)
    source = BASE/'source_r10'
    hashes = read(source/'SOURCE_MANIFEST.json')['code_sha256']
    if any(hashlib.sha256((source/'local'/n).read_bytes()).hexdigest() != h for n, h in hashes.items()):
        raise RuntimeError('Frozen r10 source changed')
    selection = BASE/'retrieval_dev48_manifest.json'
    selected = read(selection)
    parent = ROOT/'local_outputs/v74_r8_r5_retrieval_dev48_20261020'
    old_manifest = read(parent/'manifest.json')
    if old_manifest['rows'] != selected['rows']:
        raise RuntimeError('The saved r5 baseline uses a different selection')
    shared = Path(old_manifest['api']['api_slot_dir']).resolve()
    output = ROOT/'local_outputs/v74_r8_r10_retrieval_dev48_20261020'
    output.mkdir(exist_ok=False)
    (output/'.api_slots').symlink_to(shared, target_is_directory=True)
    log = BASE/'r10_retrieval_dev48.log'
    command = ['bash', str(source/'local/run_local_v9.sh'), '--predictions',
        str(BASE.parent/'r8_grounding_input_20261020/20261020_r8_object_predictions'),
        '--scene-root', str(ROOT/'local_outputs'), '--manifest', str(selection),
        '--category-top-k', '5', '--output', str(output)]
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'SEEGROUND_R8_GROUNDING_REVISION': 'r10',
           'SEEGROUND_WORKERS': '4', 'SEEGROUND_API_CONCURRENCY': '8'}
    with log.open('a') as handle:
        process = subprocess.Popen(command, cwd=source, env=env, stdout=handle, stderr=subprocess.STDOUT)
        state(status='running', revision='r10', child_pid=process.pid, output=str(output),
              source=str(source), log=str(log), shared_api_slots=str(shared))
        print(f'Started r10 matching-only synonym development: PID {process.pid}', flush=True)
        code = process.wait()
    if code:
        raise RuntimeError(f'r10 exited {code}; inspect {log}')
    manifest = read(output/'manifest.json')
    if (manifest['rows'] != old_manifest['rows'] or manifest['categories'] != old_manifest['categories']
            or manifest['models'] != old_manifest['models'] or manifest['code_sha256'] != hashes
            or Path(manifest['api']['api_slot_dir']).resolve() != shared):
        raise RuntimeError('Input, model, source or physical slot provenance differs')
    rows = {r['csv_row']: r for r in read(output/'results.json')['results']}
    before = {r['csv_row']: r for r in read(parent/'results.json')['results']}
    if len(rows) != 48 or set(rows) != set(before):
        raise RuntimeError('Incomplete development coverage')
    for key, row in rows.items():
        if any(row[k] != before[key][k] for k in ('scene', 'query', 'target_id')):
            raise RuntimeError('Query identity changed')
        if row['correct'] != (row['predicted_id'] == row['target_id'] and not row.get('error')):
            raise RuntimeError('Saved correctness is inconsistent')
        if not row.get('error'):
            pred = read(output/f'q{key:05d}/prediction.json')
            if (pred['predicted_id'] != row['predicted_id'] or pred['gt_categories_supplied_to_model']
                    or pred['query_target_id_supplied_to_model']
                    or (pred['predicted_id'] is not None and pred['predicted_id'] not in pred['category_target_ids'])):
                raise RuntimeError('Saved final prediction provenance failed')
    def compare(keys):
        return {'queries': len(keys), 'r5_correct': sum(before[k]['correct'] for k in keys),
            'r10_correct': sum(rows[k]['correct'] for k in keys),
            'gained': [k for k in keys if not before[k]['correct'] and rows[k]['correct']],
            'lost': [k for k in keys if before[k]['correct'] and not rows[k]['correct']]}
    report = {'created_at': datetime.now().astimezone().isoformat(), 'all': compare(list(rows)),
        'alias_descriptions': compare(selected['focus_csv_rows']), 'controls': compare(selected['control_csv_rows']),
        'errors': sum(bool(r.get('error')) for r in rows.values()), 'all_saved_final_predictions_checked': True,
        'frozen_modules_verified': len(hashes), 'not_independent_full_accuracy': True,
        'exposed_development_selection_reused_after_r8_scope_regression': True}
    write_json(BASE/'retrieval_fixed_dev48_comparison.json', report)
    state(status='phases_completed', revision='r10', summary=report, promotion_pending=True, goal_achieved=False)
    print(json.dumps(report, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    if (BASE/'retrieval_fixed_dev48_state.json').exists():
        raise SystemExit('Existing corrected-synonym development state: inspect the original job')
    try:
        main()
    except Exception as exc:
        state(status='failed', error=str(exc))
        raise
