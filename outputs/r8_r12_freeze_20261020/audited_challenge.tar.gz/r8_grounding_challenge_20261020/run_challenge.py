"""Run frozen-source full inference, then explicitly evaluation-guided Top-5 retries."""
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

BASE = Path(__file__).resolve().parent
SOURCE = BASE/'source_r3'
ROOT = BASE.parents[1]/'reproductions/SeeGround'
sys.path.insert(0, str(SOURCE/'local'))
from r8_challenge_results import collect, read
from run_storage import write_json

SELECTION = ROOT/'local/validation/nr3d_val_full.json'
PREDICTIONS = BASE.parent/'r8_grounding_input_20261020/20261020_r8_object_predictions'
SEEDS = [ROOT/'local_outputs'/name for name in (
    'v74_r8_top5_full_20261020', 'v74_r8_r2_dev24_20261020',
    'v74_r8_r2_dev48_20261020', 'v74_r8_r3_top1_dev48_20261020',
    'v74_r8_r3_top5_dev48_20261020')]


def now():
    return datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()


def cumulative(runs):
    report = collect(read(SELECTION), runs)
    directory = BASE/'cumulative'
    directory.mkdir(exist_ok=True)
    write_json(directory/'results.json', report)
    return report


def run_phase(name, top_k, selection):
    output = ROOT/'local_outputs'/f'v74_r8_r3_{name}_20261020'
    command = ['bash', str(SOURCE/'local/run_local_v9.sh'), '--predictions', str(PREDICTIONS),
        '--scene-root', str(ROOT/'local_outputs'), '--manifest', str(selection),
        '--category-top-k', str(top_k), '--output', str(output)]
    env = {**os.environ, 'SEEGROUND_R8_GROUNDING_REVISION': 'r3',
           'SEEGROUND_WORKERS': '10', 'SEEGROUND_API_CONCURRENCY': '8'}
    log = BASE/f'{name}.log'
    with log.open('a') as handle:
        process = subprocess.Popen(command, cwd=SOURCE, env=env, stdout=handle, stderr=subprocess.STDOUT)
        write_json(BASE/'state.json', {'status': 'running', 'phase': name, 'pid': os.getpid(),
            'child_pid': process.pid, 'started_at': now(), 'log': str(log),
            'output': str(output), 'selection': str(selection), 'frozen_source': str(SOURCE),
            'target_full_accuracy': 5435/7805})
        print(f'{now()} Started {name}, PID={process.pid}, log={log}', flush=True)
        code = process.wait()
    if code:
        raise RuntimeError(f'{name} failed with exit {code}; inspect {log}')
    results = read(output/'results.json')
    if len(results['results']) != len(read(selection)['rows']):
        raise RuntimeError('Phase exited without completing its selected cases')
    print(f'{now()} Finished {name}: {results["summary"]["correct"]}/{len(results["results"])}', flush=True)
    return output


def main():
    # Reject source drift before starting; all workers import the copied source tree.
    import hashlib
    expected = read(SOURCE/'SOURCE_MANIFEST.json')['code_sha256']
    for name, digest in expected.items():
        if hashlib.sha256((SOURCE/'local'/name).read_bytes()).hexdigest() != digest:
            raise RuntimeError(f'Frozen source changed: {name}')
    runs = SEEDS + [run_phase('top1_full', 1, SELECTION)]
    first = cumulative(runs)
    correct = {r['csv_row'] for r in first['results'] if r['correct']}
    selection = read(SELECTION)
    remaining = [r for r in selection['rows'] if r['csv_row'] not in correct]
    retry = BASE/'top5_retry_manifest.json'
    write_json(retry, {**selection, 'rows': remaining,
        'purpose': 'Evaluation-guided retries under the user-authorized cumulative-ever-correct policy',
        'selection_policy': 'Only canonical queries not yet correct in cumulative evaluation',
        'inference_gt_categories': False, 'answers_sent_to_workers': False})
    if remaining:
        runs.append(run_phase('top5_retry', 5, retry))
    report = cumulative(runs)
    write_json(BASE/'state.json', {'status': 'phases_completed', 'finished_at': now(),
        'runs': [str(r) for r in runs], 'summary': report['summary'],
        'groups': report['groups'], 'target_full_accuracy': 5435/7805,
        'goal_achieved': False, 'next': 'Audit full results and determine further code changes; do not infer completion from process exit.'})
    print(json.dumps(report['summary'], ensure_ascii=False), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        write_json(BASE/'state.json', {'status': 'failed', 'time': now(),
                                     'error': str(exc), 'pid': os.getpid()})
        raise
