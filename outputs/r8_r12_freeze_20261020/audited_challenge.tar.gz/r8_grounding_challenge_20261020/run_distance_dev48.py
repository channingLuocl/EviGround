"""Paired r5/r6 development run, isolated from the existing full phases."""
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'
sys.path.insert(0, str(ROOT/'local'))
from run_storage import write_json


def read(path):
    return json.loads(path.read_text())


def state(**fields):
    write_json(BASE/'distance_dev48_state.json',
               {'time': datetime.now().astimezone().isoformat(), 'pid': os.getpid(), **fields})


def main():
    selection = BASE/'distance_dev48_manifest.json'
    expected_selection = read(BASE/'distance_dev48_selection_audit.json')['selection_manifest_sha256']
    if hashlib.sha256(selection.read_bytes()).hexdigest() != expected_selection:
        raise RuntimeError('Development selection changed')
    records = {}
    for revision in ('r5', 'r6'):
        source = BASE/f'source_{revision}'
        hashes = read(source/'SOURCE_MANIFEST.json')['code_sha256']
        if any(hashlib.sha256((source/'local'/n).read_bytes()).hexdigest() != h for n, h in hashes.items()):
            raise RuntimeError('Frozen development source changed')
        output = ROOT/'local_outputs'/f'v74_r8_{revision}_distance_dev48_20261020'
        command = ['bash', str(source/'local/run_local_v9.sh'), '--predictions',
            str(BASE.parent/'r8_grounding_input_20261020/20261020_r8_object_predictions'),
            '--scene-root', str(ROOT/'local_outputs'), '--manifest', str(selection),
            '--category-top-k', '1', '--output', str(output)]
        env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'SEEGROUND_R8_GROUNDING_REVISION': revision,
               'SEEGROUND_WORKERS': '4', 'SEEGROUND_API_CONCURRENCY': '8'}
        log = BASE/f'{revision}_distance_dev48.log'
        with log.open('a') as handle:
            process = subprocess.Popen(command, cwd=source, env=env, stdout=handle, stderr=subprocess.STDOUT)
            state(status='running', revision=revision, child_pid=process.pid,
                  output=str(output), log=str(log), shared_api_slots=8)
            print(f'Started {revision}: PID {process.pid}', flush=True)
            code = process.wait()
        if code:
            raise RuntimeError(f'{revision} exited {code}; inspect its preserved log')
        result = read(output/'results.json')
        if len(result['results']) != 48:
            raise RuntimeError('Development run is incomplete')
        if read(output/'manifest.json')['code_sha256'] != hashes:
            raise RuntimeError('Run differs from its frozen source')
        for row in result['results']:
            pred = output/f"q{row['csv_row']:05d}/prediction.json"
            if pred.exists():
                data = read(pred)
                if data['gt_categories_supplied_to_model'] or data['query_target_id_supplied_to_model']:
                    raise RuntimeError('Evaluation labels entered inference')
        records[revision] = {'correct': result['summary']['correct'],
                             'errors': result['summary'].get('errors', 0), 'output': str(output)}
        print(json.dumps({revision: records[revision]}, ensure_ascii=False), flush=True)
    state(status='phases_completed', runs=records, promotion_pending=True, goal_achieved=False)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        state(status='failed', error=str(exc))
        raise
