"""Independently compare saved category inputs with the original predicted export."""
from collections import defaultdict
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZipFile

BASE = Path(__file__).resolve().parent
EXPORT = BASE.parent/'r8_grounding_input_20261020/20261020_r8_object_predictions'
ARCHIVE = BASE.parent/'r8_best_object_predictions_20261020.zip'


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def main():
    raw = (BASE/'progress_cumulative.json').read_bytes()
    snapshot_sha = hashlib.sha256(raw).hexdigest()
    snapshot_path = BASE/'audit_snapshots'/f'{snapshot_sha}.json'
    snapshot_path.parent.mkdir(exist_ok=True)
    if not snapshot_path.exists():
        snapshot_path.write_bytes(raw)
    snapshot = json.loads(raw)
    marker = read(EXPORT/'EXPORT_VERIFIED.json')
    assert marker['status'] == 'passed'
    with ZipFile(ARCHIVE) as archive:
        names = [n for n in archive.namelist() if n.endswith('/EXPORT_VERIFIED.json')]
        assert len(names) == 1
        prefix = names[0][:-len('EXPORT_VERIFIED.json')]
        for name in ('predictions.json', 'config.json', 'EXPORT_VERIFIED.json'):
            exported = (EXPORT/name).read_bytes()
            assert archive.read(prefix+name) == exported, name
            if name in marker['files']:
                assert hashlib.sha256(exported).hexdigest() == marker['files'][name], name
    predictions, config = read(EXPORT/'predictions.json'), read(EXPORT/'config.json')
    assert snapshot['summary']['source_predictions_sha256'] == marker['files']['predictions.json']
    scenes = {r['scene']: r['cloud_sha256'] for r in config['sources']}
    by_scene = defaultdict(list)
    for row in predictions['results']:
        by_scene[row['scene']].append(row)
    assert len(scenes) == len(by_scene) == 130
    assert sum(map(len, by_scene.values())) == 3413
    geometry_hashes, table_digests, runs = {}, {}, []
    for run in snapshot['single_pass_runs']:
        directory = Path(run['run'])
        assert sha(directory/'manifest.json') == run['manifest_sha256']
        manifest = read(directory/'manifest.json')
        categories, scene_root = manifest['categories'], Path(manifest['scene_root'])
        top_k = categories['gate']['top_k']
        assert top_k in (1, 5)
        assert categories['gate'] == {'top_k': top_k, 'score_type': config['score_type']}
        for name in ('predictions', 'config'):
            assert categories[f'source_{name}_sha256'] == marker['files'][f'{name}.json']
        assert set(categories['files']) == {r['scene'] for r in manifest['rows']}
        count = 0
        for scene, expected_hash in categories['files'].items():
            path = directory/'category_inputs'/scene/f'objects_top{top_k}.json'
            actual_hash = sha(path)
            assert actual_hash == expected_hash, str(path)
            table = read(path)
            assert table['scene'] == scene and table['gate'] == categories['gate']
            assert table['cloud_sha256'] == scenes[scene]
            assert table['source_predictions_sha256'] == marker['files']['predictions.json']
            assert table['source_config_sha256'] == marker['files']['config.json']
            expected_objects = []
            for obj in sorted(by_scene[scene], key=lambda r: r['bbox_id']):
                hypotheses, gate_audit = [], []
                for rank, h in enumerate(obj['top5'], 1):
                    assert h['rank'] == rank
                    item = {'category': h['category'], 'score': float(h['score']),
                            'rank': rank, 'gap_from_top1': float(obj['top5'][0]['score']-h['score'])}
                    retained = rank <= top_k
                    gate_audit.append({**item, 'retained': retained,
                                       'reasons': [] if retained else ['outside_top_k']})
                    if retained:
                        hypotheses.append(item)
                expected_objects.append({'bbox_id': obj['bbox_id'], 'target': obj['predicted_object'],
                    'bbox_3d': obj['bbox_3d'], 'top5': obj['top5'],
                    'category_hypotheses': hypotheses, 'category_gate_audit': gate_audit,
                    'category_status': 'single_hypothesis' if top_k == 1 else 'uncertain'})
            # Exact equality also excludes injected GT/evaluation fields in these objects.
            assert table['objects'] == expected_objects, str(path)
            table_digests[str(path)] = actual_hash
            count += len(expected_objects)
            for name, expected in manifest['scene_sha256'][scene].items():
                asset = (scene_root/scene/name).resolve()
                if str(asset) not in geometry_hashes:
                    geometry_hashes[str(asset)] = sha(asset)
                assert geometry_hashes[str(asset)] == expected, str(asset)
                if name == 'scene.npz':
                    assert expected == scenes[scene], scene
        runs.append({'run': str(directory), 'top_k': top_k, 'category_tables': len(categories['files']),
                     'classified_instances_checked': count, 'manifest_sha256': run['manifest_sha256']})
    primary = next(Path(r['run']) for r in runs if Path(r['run']).name == 'v74_r8_r3_top1_full_20261020')
    primary_manifest = read(primary/'manifest.json')
    source = BASE/'source_r3/local'
    source_hashes = {name: sha(source/name) for name in ('run.py', 'real_scene.py', 'categories_v9.py')}
    assert all(primary_manifest['code_sha256'][name] == digest for name, digest in source_hashes.items())
    sys.path.insert(0, str(source))
    from categories_v9 import load_category_objects
    from real_scene import structural_objects
    anonymous_count = 0
    for scene in primary_manifest['categories']['files']:
        objects = load_category_objects(primary/'category_inputs'/scene/'objects_top1.json')
        anonymous = structural_objects(Path(primary_manifest['scene_root'])/scene, objects, 'v9_top1')
        assert all(o['target'] == 'object' and set(o) == {'bbox_id', 'target', 'bbox_3d'} for o in anonymous)
        assert all(set(o) == {'bbox_id', 'target', 'bbox_3d', 'category_hypotheses',
                             'category_status', 'category_score_type'} for o in objects)
        anonymous_count += len(anonymous)
    report = {'created_at': datetime.now().astimezone().isoformat(),
        'cumulative_snapshot_sha256': snapshot_sha, 'cumulative_snapshot_path': str(snapshot_path),
        'original_zip_sha256': sha(ARCHIVE), 'source_predictions_sha256': marker['files']['predictions.json'],
        'original_zip_matches_extracted_export': True, 'independent_rank_only_projection_matches': True,
        'scene_assets_match_recorded_hashes': True, 'unique_scene_assets_checked': len(geometry_hashes),
        'category_tables_checked': len(table_digests), 'category_table_hashes': table_digests, 'runs': runs,
        'r3_runtime_loader_check': {'scenes': len(primary_manifest['categories']['files']),
            'anonymous_supplemental_instances': anonymous_count, 'object_field_whitelist_passed': True,
            'source_sha256': source_hashes},
        'not_a_completion_audit': True,
        'limitations': 'Verifies current saved static input files against original predictions and recorded identities. '
            'Does not capture historical serialized API requests or prove every dynamic code path label-free. '
            'scene_instances.json contains annotated categories; their anonymization requires source-flow review. '
            'Instance IDs, masks and geometry remain annotation-derived; this is predicted-category grounding, '
            'not an end-to-end predicted-instance benchmark. Cumulative selection is evaluation-guided.'}
    (BASE/'static_inputs_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('category_table_hashes', 'runs')},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
