"""Run the isolated target-referent parser comparison after synonym development."""
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'
sys.path.insert(0, str(ROOT/'local'))
from run_storage import write_json


def read(path):
    return json.loads(path.read_text())


def state(**fields):
    write_json(BASE/'referent_dev48_state.json',
               {'time': datetime.now().astimezone().isoformat(), 'pid': os.getpid(), **fields})


def main():
    if read(BASE/'retrieval_dev48_state.json')['status'] != 'phases_completed':
        raise RuntimeError('Finish the existing synonym development run first')
    selection = BASE/'referent_dev48_manifest.json'
    expected = read(selection)['rows']
    if len(expected) != 48:
        raise RuntimeError('Expected the fixed 48-query development selection')
    shared = (ROOT/'local_outputs/v74_r8_r5_top5_retry_20261020/.api_slots').resolve()
    records = {}
    for revision in ('r5', 'r9'):
        source = BASE/f'source_{revision}'
        hashes = read(source/'SOURCE_MANIFEST.json')['code_sha256']
        if any(hashlib.sha256((source/'local'/n).read_bytes()).hexdigest() != h for n, h in hashes.items()):
            raise RuntimeError('Frozen development source changed')
        output = ROOT/'local_outputs'/f'v74_r8_{revision}_referent_dev48_20261020'
        output.mkdir(exist_ok=False)
        (output/'.api_slots').symlink_to(shared, target_is_directory=True)
        log = BASE/f'{revision}_referent_dev48.log'
        command = ['bash', str(source/'local/run_local_v9.sh'), '--predictions',
            str(BASE.parent/'r8_grounding_input_20261020/20261020_r8_object_predictions'),
            '--scene-root', str(ROOT/'local_outputs'), '--manifest', str(selection),
            '--category-top-k', '5', '--output', str(output)]
        env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1',
               'SEEGROUND_R8_GROUNDING_REVISION': revision,
               'SEEGROUND_WORKERS': '4', 'SEEGROUND_API_CONCURRENCY': '8'}
        with log.open('a') as handle:
            process = subprocess.Popen(command, cwd=source, env=env, stdout=handle, stderr=subprocess.STDOUT)
            state(status='running', revision=revision, child_pid=process.pid,
                  output=str(output), log=str(log), shared_api_slots=str(shared))
            print(f'Started {revision} referent development: PID {process.pid}', flush=True)
            code = process.wait()
        if code:
            raise RuntimeError(f'{revision} exited {code}; inspect {log}')
        result = read(output/'results.json')
        manifest = read(output/'manifest.json')
        if len(result['results']) != 48 or manifest['rows'] != expected:
            raise RuntimeError('Incomplete or changed development selection')
        if manifest['code_sha256'] != hashes or Path(manifest['api']['api_slot_dir']).resolve() != shared:
            raise RuntimeError('Frozen source or shared API slots changed')
        records[revision] = {'correct': result['summary']['correct'],
            'errors': result['summary'].get('errors', 0), 'output': str(output)}
        print(json.dumps({revision: records[revision]}, ensure_ascii=False), flush=True)
    state(status='phases_completed', runs=records, final_prediction_audit_pending=True,
          promotion_pending=True, goal_achieved=False)


if __name__ == '__main__':
    if (BASE/'referent_dev48_state.json').exists():
        raise SystemExit('Existing referent development state: inspect the original job')
    try:
        main()
    except Exception as exc:
        state(status='failed', error=str(exc))
        raise
