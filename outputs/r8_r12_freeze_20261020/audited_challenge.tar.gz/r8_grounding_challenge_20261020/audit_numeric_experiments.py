"""Post-inference development comparison, including the executor's actual marginal effect."""
from collections import Counter
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'


def read(path):
    return json.loads(path.read_text())


def audit(revision):
    directory = ROOT/'local_outputs'/f'v74_r8_{revision}_top1_dev48_20261020'
    manifest = read(directory/'manifest.json')
    selected = {r['csv_row']: r for r in manifest['rows']}
    rows, gains, losses, execution = [], [], [], []
    blocked = Counter()
    for i, source in sorted(selected.items()):
        folder = directory/f'q{i:05d}'
        if not (folder/'evaluation.json').exists():
            continue
        row = read(folder/'evaluation.json')
        assert all(row[k] == source[k] for k in ('query', 'scene', 'target_id'))
        if row.get('error'):
            rows.append({'csv_row': i, 'error': row['error'], 'correct': False})
            continue
        pred = read(folder/'prediction.json')
        trace = pred['active_trace']
        assert pred['gt_categories_supplied_to_model'] is False
        assert pred['query_target_id_supplied_to_model'] is False
        assert pred['predicted_id'] in trace['final_candidate_ids']+[None]
        before = trace.get('r4_original_scene_decision', {}).get('predicted_id', pred['predicted_id'])
        before_ok = before == row['target_id']
        proof = trace.get('r4_numeric_execution', {})
        if proof.get('applied'):
            claim = pred['scene_evidence']['numeric_choice']
            pool = claim['eligible_ids']
            payload = trace['r8_scene_input']
            if claim['predicate'] in ('leftmost', 'rightmost'):
                frames = payload['observer_frames']
                frame = (next(f for f in frames if f.get('frame_id') == claim['frame_id'])
                         if 'frame_id' in claim else frames[claim['frame_index']])
                values = {r[0]: r[1] for r in frame['rows_left_to_right'] if r[0] in pool}
            else:
                frame = None
                values = {o['id']: o['height_m'] for o in payload['objects'] if o['id'] in pool}
            extreme = (max if claim['predicate'] in ('rightmost', 'tallest') else min)(values.values())
            assert values[pred['predicted_id']] == extreme
            assert sum(v == extreme for v in values.values()) == 1
            execution.append({'csv_row': i, 'before_id': before, 'after_id': pred['predicted_id'],
                'before_correct': before_ok, 'after_correct': row['correct'], 'claim': claim,
                'frame': frame, 'proof': proof})
            if row['correct'] and not before_ok:
                gains.append(i)
            if before_ok and not row['correct']:
                losses.append(i)
        else:
            blocked[proof.get('reason', 'No numeric stage')]+=1
        rows.append({'csv_row': i, 'correct': row['correct'], 'before_correct': before_ok,
                     'predicted_id': pred['predicted_id'], 'view_dep': row['view_dep']})
    return {'selected': len(selected), 'evaluated': len(rows),
        'complete': len(rows) == len(selected), 'correct': sum(r['correct'] for r in rows),
        'errors': sum('error' in r for r in rows),
        'executor_applied': len(execution), 'executor_wrong_to_correct': gains,
        'executor_correct_to_wrong': losses, 'executor_blocked_reasons': dict(blocked),
        'execution_cases': execution, 'cases': rows}


def main():
    report = {revision: audit(revision) for revision in ('r3', 'r4', 'r5')}
    common = set.intersection(*[{r['csv_row'] for r in d['cases']} for d in report.values()])
    paired = {'common_completed': len(common), 'all_complete': all(d['complete'] for d in report.values()),
        'correct_on_common': {rev: sum(r['correct'] for r in d['cases'] if r['csv_row'] in common)
                              for rev, d in report.items()},
        'note': 'Exposed development set; code differs deliberately; no full-set improvement claim.'}
    report['paired'] = paired
    (BASE/'numeric_dev48_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({rev: {k: v for k, v in d.items() if k not in ('cases', 'execution_cases')}
                      for rev, d in report.items()}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
