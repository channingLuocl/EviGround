"""Run frozen r5 with Top-5 on the remaining evaluation-oracle failure set."""
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from zoneinfo import ZoneInfo

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'
SOURCE = BASE/'source_r5'
OUTPUT = ROOT/'local_outputs/v74_r8_r5_top5_retry_20261020'
STATE = BASE/'r5_top5_retry_state.json'
sys.path.insert(0, str(ROOT/'local'))
from r8_challenge_results import collect, read
from run_storage import write_json


def status(**fields):
    write_json(STATE, {'time': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
                      'pid': os.getpid(), **fields})


def main():
    if read(BASE/'conditional_rescue_state.json')['status'] != 'phase_completed':
        raise RuntimeError('The original r5 phase must finish before this retry')
    phase = read(BASE/'r5_phase_audit.json')
    audit = read(BASE/'r5_saved_final_predictions_audit.json')
    if (not audit['saved_final_consistency_passed']
            or audit['attempts_checked'] != phase['selected']
            or audit['snapshot_summary']['correct'] != phase['correct']):
        raise RuntimeError('Complete r5 final-prediction verification is required')
    baseline_raw = (BASE/'progress_cumulative.json').read_bytes()
    baseline = json.loads(baseline_raw)
    if (not baseline['summary']['complete']
            or baseline['summary']['correct'] != phase['baseline_plus_r5_correct']):
        raise RuntimeError('Refresh the complete all-source post-r5 baseline first')
    expected = read(SOURCE/'SOURCE_MANIFEST.json')['code_sha256']
    parent = ROOT/'local_outputs/v74_r8_r5_conditional_rescue_20261020'
    if read(parent/'manifest.json')['code_sha256'] != expected:
        raise RuntimeError('Frozen r5 differs from the completed parent phase')
    for name, digest in expected.items():
        if hashlib.sha256((SOURCE/'local'/name).read_bytes()).hexdigest() != digest:
            raise RuntimeError(f'Frozen r5 source changed: {name}')
    digest = hashlib.sha256(baseline_raw).hexdigest()
    archive = BASE/'audit_snapshots'/f'{digest}.json'
    if not archive.exists():
        archive.write_bytes(baseline_raw)
    if archive.read_bytes() != baseline_raw:
        raise RuntimeError('Archived baseline does not match the fixed input')
    canonical = read(ROOT/'local/validation/nr3d_val_full.json')
    rows = {r['csv_row']: r for r in canonical['rows']}
    if set(rows) != {r['csv_row'] for r in baseline['results']}:
        raise RuntimeError('The baseline lacks complete canonical coverage')
    for row in baseline['results']:
        if any(row[k] != rows[row['csv_row']][k] for k in ('scene', 'query', 'target_id')):
            raise RuntimeError('Baseline query identity changed')
    remaining = {r['csv_row'] for r in baseline['results'] if not r['correct']}
    if (len(remaining) != phase['remaining_count']
            or not set(phase['execution_error_csv_rows']).issubset(remaining)):
        raise RuntimeError('The retry selection differs from the audited failure set')
    selection = {**canonical, 'rows': [r for r in canonical['rows'] if r['csv_row'] in remaining],
        'purpose': 'User-authorized evaluation-guided r5 Top-5 cumulative retry',
        'selection_policy': 'Only queries never correct in prior saved final predictions',
        'baseline_snapshot_sha256': digest, 'inference_gt_categories': False,
        'answers_sent_to_workers': False}
    selection_path = BASE/'r5_top5_retry_manifest.json'
    write_json(selection_path, selection)
    command = ['bash', str(SOURCE/'local/run_local_v9.sh'), '--predictions',
        str(BASE.parent/'r8_grounding_input_20261020/20261020_r8_object_predictions'),
        '--scene-root', str(ROOT/'local_outputs'), '--manifest', str(selection_path),
        '--category-top-k', '5', '--output', str(OUTPUT)]
    env = {**os.environ, 'SEEGROUND_R8_GROUNDING_REVISION': 'r5',
           'SEEGROUND_WORKERS': '10', 'SEEGROUND_API_CONCURRENCY': '8'}
    log = BASE/'r5_top5_retry.log'
    with log.open('a') as handle:
        process = subprocess.Popen(command, cwd=SOURCE, env=env, stdout=handle,
                                   stderr=subprocess.STDOUT)
        status(status='running', phase='r5_top5_retry', revision='r5', category_top_k=5,
               child_pid=process.pid, source=str(SOURCE), output=str(OUTPUT), log=str(log),
               selection=str(selection_path), selected=len(remaining),
               baseline_snapshot_sha256=digest, baseline_correct=baseline['summary']['correct'])
        print(f'Started r5 Top-5 for {len(remaining)} remaining queries; child PID {process.pid}', flush=True)
        code = process.wait()
    if code:
        raise RuntimeError(f'r5 Top-5 exited {code}; inspect {log}')
    if len(read(OUTPUT/'results.json')['results']) != len(remaining):
        raise RuntimeError('r5 Top-5 exited before completing its selection')
    report = collect(canonical, [Path(r['run']) for r in baseline['single_pass_runs']]+[OUTPUT])
    write_json(BASE/'cumulative/results.json', report)
    status(status='phase_completed', phase='r5_top5_retry', revision='r5', category_top_k=5,
           summary=report['summary'], groups=report['groups'], completion_audit_pending=True,
           goal_achieved=False)
    print(json.dumps(report['summary'], ensure_ascii=False), flush=True)


if __name__ == '__main__':
    if OUTPUT.exists() or STATE.exists():
        raise SystemExit('Existing r5 Top-5 output/state found; inspect the original job before any retry')
    try:
        main()
    except Exception as exc:
        status(status='failed', error=str(exc))
        raise
