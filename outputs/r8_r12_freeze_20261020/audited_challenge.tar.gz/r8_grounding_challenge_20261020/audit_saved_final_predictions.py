"""Verify saved final outputs behind a fixed cumulative snapshot; no inference."""
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'


def read(path):
    return json.loads(path.read_bytes())


def main(snapshot_path=None, output_path=None):
    raw = Path(snapshot_path or BASE/'progress_cumulative.json').read_bytes()
    snapshot_digest = hashlib.sha256(raw).hexdigest()
    snapshot_path = BASE/'audit_snapshots'/f'{snapshot_digest}.json'
    snapshot_path.parent.mkdir(exist_ok=True)
    if not snapshot_path.exists():
        snapshot_path.write_bytes(raw)
    snapshot = json.loads(raw)
    canonical = {r['csv_row']: r for r in read(ROOT/'local/validation/nr3d_val_full.json')['rows']}
    attempts = [(int(key), a) for key, rows in snapshot['attempt_history'].items() for a in rows]

    def inspect(item):
        i, attempt = item
        directory = Path(attempt['run'])/f'q{i:05d}'
        evaluation_raw = (directory/'evaluation.json').read_bytes()
        evaluation = json.loads(evaluation_raw)
        issues = []
        if any(evaluation.get(k) != canonical[i][k]
               for k in ('csv_row', 'scene', 'query', 'target_id', 'easy', 'view_dep')):
            issues.append('evaluation identity differs from canonical query')
        for k in ('predicted_id', 'correct', 'error'):
            if evaluation.get(k) != attempt.get(k):
                issues.append(f'saved evaluation differs from snapshot: {k}')
        correct = evaluation.get('predicted_id') == canonical[i]['target_id'] and not evaluation.get('error')
        if bool(evaluation.get('correct')) != bool(correct):
            issues.append('correctness differs from saved final ID')
        prediction_digest = None
        if not evaluation.get('error'):
            path = directory/'prediction.json'
            if not path.exists():
                issues.append('successful evaluation has no saved final prediction')
            else:
                prediction_raw = path.read_bytes()
                prediction_digest = hashlib.sha256(prediction_raw).hexdigest()
                prediction = json.loads(prediction_raw)
                if prediction.get('query') != canonical[i]['query']:
                    issues.append('prediction query differs from canonical query')
                if prediction.get('predicted_id') != evaluation.get('predicted_id'):
                    issues.append('evaluation does not use saved final prediction ID')
                for flag in ('gt_categories_supplied_to_model', 'query_target_id_supplied_to_model'):
                    if prediction.get(flag) is not False:
                        issues.append(f'inference flag is missing or not false: {flag}')
                allowed = prediction.get('category_target_ids')
                if not isinstance(allowed, list):
                    issues.append('retrieved target ID list is missing')
                elif prediction.get('predicted_id') is not None and prediction['predicted_id'] not in allowed:
                    issues.append('saved final prediction lies outside retrieved targets')
        return {'run': attempt['run'], 'csv_row': i, 'issues': issues,
                'execution_error': bool(evaluation.get('error')),
                'evaluation_sha256': hashlib.sha256(evaluation_raw).hexdigest(),
                'prediction_sha256': prediction_digest}

    with ThreadPoolExecutor(max_workers=4) as pool:
        checked = list(pool.map(inspect, attempts))
    violations = [r for r in checked if r['issues']]
    counts = Counter(r['run'] for r in checked)
    errors = Counter(r['run'] for r in checked if r['execution_error'])
    digest = hashlib.sha256()
    for row in checked:
        digest.update(json.dumps(row, sort_keys=True).encode())
    chosen_issues = []
    for row in snapshot['results']:
        history = snapshot['attempt_history'][str(row['csv_row'])]
        if not any(a['run'] == row['cumulative_source_run'] and
                   a['predicted_id'] == row.get('predicted_id') and
                   a['correct'] == row['correct'] for a in history):
            chosen_issues.append(row['csv_row'])
        if bool(row['correct']) != any(a['correct'] for a in history):
            chosen_issues.append(row['csv_row'])
    report = {'created_at': datetime.now().astimezone().isoformat(),
        'cumulative_snapshot_sha256': snapshot_digest,
        'cumulative_snapshot_path': str(snapshot_path),
        'snapshot_summary': snapshot['summary'], 'attempts_checked': len(checked),
        'saved_artifact_digest': digest.hexdigest(),
        'successful_attempts_checked': sum(not r['execution_error'] for r in checked),
        'execution_error_attempts_preserved': sum(r['execution_error'] for r in checked),
        'violations': violations, 'cumulative_selection_violations': sorted(set(chosen_issues)),
        'saved_final_consistency_passed': not violations and not chosen_issues,
        'per_run': [{'run': run, 'attempts_checked': count, 'execution_errors': errors[run]}
                    for run, count in counts.items()],
        'not_a_completion_audit': True,
        'limitations': 'Checks saved final outputs and recorded GT-input flags only. Static inference-input provenance, source preservation, complete coverage, usage accounting and goal attainment require separate audits. Cumulative correct retention remains an evaluation oracle.'}
    Path(output_path or BASE/'saved_final_predictions_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'per_run'}, ensure_ascii=False, indent=2))
    if not report['saved_final_consistency_passed']:
        raise SystemExit('Saved final prediction audit found inconsistencies')


if __name__ == '__main__':
    main()
