"""Audit saved final predictions and the marginal effect of numeric execution."""
import hashlib
import json
from pathlib import Path
import re
from collections import Counter

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'


def read(path):
    return json.loads(path.read_text())


def main():
    selected = read(BASE/'distance_dev48_manifest.json')['rows']
    ids = {r['csv_row'] for r in selected}
    distance_ids = {r['csv_row'] for r in selected if re.search(
        r'\b(?:nearest|closest|farthest|furthest)\b', r['query'], re.I)}
    runs, cases, manifests = {}, {}, {}
    for revision in ('r5', 'r6'):
        directory = ROOT/'local_outputs'/f'v74_r8_{revision}_distance_dev48_20261020'
        manifest = read(directory/'manifest.json')
        expected = read(BASE/f'source_{revision}/SOURCE_MANIFEST.json')['code_sha256']
        assert manifest['code_sha256'] == expected
        assert all(hashlib.sha256((BASE/f'source_{revision}/local'/n).read_bytes()).hexdigest() == h
                   for n, h in expected.items())
        result = read(directory/'results.json')
        rows = {r['csv_row']: r for r in result['results']}
        assert set(rows) == ids, 'Wait for all 48 final evaluations before comparing'
        measurements, blocked = [], Counter()
        for index, row in rows.items():
            assert row['correct'] == (row['predicted_id'] == row['target_id'] and not row.get('error'))
            path = directory/f'q{index:05d}/prediction.json'
            if not path.exists():
                assert row.get('error')
                continue
            prediction = read(path)
            assert not prediction['gt_categories_supplied_to_model']
            assert not prediction['query_target_id_supplied_to_model']
            trace = prediction.get('active_trace', {})
            proof = trace.get('r4_numeric_execution', {})
            if proof.get('applied'):
                before = trace['r4_original_scene_decision']['predicted_id']
                assert prediction['predicted_id'] == proof['after_id']
                measurements.append({'csv_row': index, 'predicate': proof['predicate'],
                    'before_id': before, 'after_id': row['predicted_id'],
                    'before_correct': before == row['target_id'], 'after_correct': row['correct'],
                    'reference_id': proof.get('reference_id'), 'metric': proof.get('distance_metric'),
                    'ordinal': proof.get('ordinal'), 'binding_status': proof['binding_status']})
            else:
                blocked[proof.get('reason', 'No numeric stage')] += 1
        def group(group_ids):
            return {'queries': len(group_ids), 'correct': sum(rows[i]['correct'] for i in group_ids),
                    'target_recalled': sum(bool(rows[i].get('category_candidate_recall')) for i in group_ids)}
        attempts = sum(r.get('api_attempts', 0) for r in rows.values())
        usage = [u for r in rows.values() for u in r.get('call_usage', []) if isinstance(u, dict)]
        runs[revision] = {'all': group(ids), 'distance': group(distance_ids),
            'control': group(ids-distance_ids), 'errors': sum(bool(r.get('error')) for r in rows.values()),
            'api_attempts': attempts, 'reported_total_tokens': sum(u.get('total_tokens', 0) for u in usage),
            'unreported_usage_attempts': max(0, attempts-sum('total_tokens' in u for u in usage)),
            'numeric_applied': len(measurements),
            'numeric_wrong_to_correct': [r['csv_row'] for r in measurements if not r['before_correct'] and r['after_correct']],
            'numeric_correct_to_wrong': [r['csv_row'] for r in measurements if r['before_correct'] and not r['after_correct']],
            'numeric_blocked_reasons': dict(blocked), 'executions': measurements}
        cases[revision], manifests[revision] = rows, manifest
    for key in ('rows', 'selection_sha256', 'categories', 'scene_sha256', 'workers', 'review_limit', 'models'):
        assert manifests['r5'][key] == manifests['r6'][key], f'Non-code setting differs: {key}'
    api5, api6 = dict(manifests['r5']['api']), dict(manifests['r6']['api'])
    assert Path(api5.pop('api_slot_dir')).resolve() == Path(api6.pop('api_slot_dir')).resolve()
    assert api5 == api6, 'Model request settings differ'
    gained = [i for i in sorted(ids) if not cases['r5'][i]['correct'] and cases['r6'][i]['correct']]
    lost = [i for i in sorted(ids) if cases['r5'][i]['correct'] and not cases['r6'][i]['correct']]
    reference = [read(ROOT/'local_outputs/v74_r8_r3_top1_full_20261020'/f'q{i:05d}/evaluation.json')
                 for i in sorted(ids)]
    cumulative_correct = {r['csv_row'] for r in reference if r['correct']}
    for rows in cases.values():
        cumulative_correct.update(i for i, row in rows.items() if row['correct'])
    report = {'selection': '32 distance descriptions + 16 controls; targeted exposed development, not full validation',
        'r3_existing_final_predictions': {'correct': sum(r['correct'] for r in reference),
            'distance_correct': sum(r['correct'] for r in reference if r['csv_row'] in distance_ids),
            'control_correct': sum(r['correct'] for r in reference if r['csv_row'] not in distance_ids)},
        'r3_r5_r6_cumulative_correct': len(cumulative_correct),
        'additional_cumulative_correct_over_r3': len(cumulative_correct)-sum(r['correct'] for r in reference),
        'runs': runs, 'paired': {'gained': gained, 'lost': lost, 'net_correct': len(gained)-len(lost)},
        'inference_label_flags_checked': True, 'source_hashes_verified': True,
        'goal_achieved': False, 'promotion_requires_review': True}
    (BASE/'distance_dev48_comparison.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'runs'}, ensure_ascii=False))
    for revision, summary in runs.items():
        print(json.dumps({revision: {k: v for k, v in summary.items() if k != 'executions'}}, ensure_ascii=False))


if __name__ == '__main__':
    main()
