"""Audit the completed r5/r9 pair using saved final predictions only."""
from datetime import datetime
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'


def read(path):
    return json.loads(path.read_bytes())


def main():
    if read(BASE/'referent_dev48_state.json')['status'] != 'phases_completed':
        raise RuntimeError('The original paired run is still active')
    selection = read(BASE/'referent_dev48_manifest.json')
    canonical = {r['csv_row']: r for r in read(ROOT/'local/validation/nr3d_val_full.json')['rows']}
    manifests, runs, rows, final_hashes = {}, {}, {}, []
    for revision in ('r5', 'r9'):
        output = ROOT/'local_outputs'/f'v74_r8_{revision}_referent_dev48_20261020'
        manifest = read(output/'manifest.json')
        hashes = read(BASE/f'source_{revision}/SOURCE_MANIFEST.json')['code_sha256']
        assert manifest['rows'] == selection['rows']
        assert manifest['code_sha256'] == hashes
        for name, digest in hashes.items():
            assert hashlib.sha256((BASE/f'source_{revision}/local'/name).read_bytes()).hexdigest() == digest
        result = read(output/'results.json')
        selected = {r['csv_row']: r for r in result['results']}
        assert len(selected) == len(selection['rows']) == 48
        assert set(selected) == {r['csv_row'] for r in selection['rows']}
        for key, row in selected.items():
            saved = read(output/f'q{key:05d}/evaluation.json')
            for field in ('csv_row', 'scene', 'query', 'target_id', 'easy', 'view_dep'):
                assert row[field] == saved[field] == canonical[key][field], (revision, key, field)
            for field in ('predicted_id', 'correct', 'error'):
                assert row.get(field) == saved.get(field), (revision, key, field)
            assert type(row['correct']) is bool
            assert row['predicted_id'] is None or type(row['predicted_id']) is int
            assert row['correct'] == (row['predicted_id'] == canonical[key]['target_id'] and not row.get('error'))
            if not row.get('error'):
                raw = (output/f'q{key:05d}/prediction.json').read_bytes()
                pred = json.loads(raw)
                assert pred['query'] == canonical[key]['query']
                assert pred['predicted_id'] == row['predicted_id']
                assert pred['gt_categories_supplied_to_model'] is False
                assert pred['query_target_id_supplied_to_model'] is False
                assert pred['predicted_id'] is None or pred['predicted_id'] in pred['category_target_ids']
                final_hashes.append([revision, key, hashlib.sha256(raw).hexdigest()])
        manifests[revision], rows[revision] = manifest, selected
        runs[revision] = {'correct': sum(r['correct'] for r in selected.values()),
            'errors': sum(bool(r.get('error')) for r in selected.values()),
            'api_attempts': result['summary']['actual_api_attempts'], 'output': str(output)}
        assert runs[revision]['correct'] == result['summary']['correct']
    before, after = manifests['r5'], manifests['r9']
    for field in ('selection_sha256', 'rows', 'categories', 'scene_root', 'scene_sha256', 'review_limit', 'workers', 'models'):
        assert before[field] == after[field], field
    for field in ('policy', 'query_syntax'):
        excluded = {'version', 'implementation_version'}
        assert {k: v for k, v in before[field].items() if k not in excluded} == {k: v for k, v in after[field].items() if k not in excluded}, field
    assert {k: v for k, v in before['api'].items() if k != 'api_slot_dir'} == {k: v for k, v in after['api'].items() if k != 'api_slot_dir'}
    shared = (ROOT/'local_outputs/v74_r8_r5_top5_retry_20261020/.api_slots').resolve()
    assert all(Path(m['api']['api_slot_dir']).resolve() == shared for m in manifests.values())
    changed = sorted(k for k in before['code_sha256'] if before['code_sha256'][k] != after['code_sha256'][k])
    assert changed == ['real_scene.py', 'v4_policy.py'], changed

    def compare(keys):
        return {'queries': len(keys),
            'r5_correct': sum(rows['r5'][k]['correct'] for k in keys),
            'r9_correct': sum(rows['r9'][k]['correct'] for k in keys),
            'gained': [k for k in keys if not rows['r5'][k]['correct'] and rows['r9'][k]['correct']],
            'lost': [k for k in keys if rows['r5'][k]['correct'] and not rows['r9'][k]['correct']]}

    report = {'created_at': datetime.now().astimezone().isoformat(),
        'all': compare(sorted(rows['r5'])), 'referent_descriptions': compare(selection['focus_csv_rows']),
        'controls': compare(selection['control_csv_rows']), 'runs': runs,
        'all_saved_final_predictions_checked': True, 'paired_input_models_syntax_api_checked': True,
        'frozen_modules_verified_per_run': len(before['code_sha256']), 'only_changed_modules': changed,
        'saved_final_hashes': final_hashes, 'not_independent_full_accuracy': True,
        'selection_policy': selection['selection_policy'], 'promotion_decision_pending': True}
    (BASE/'referent_dev48_comparison.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'saved_final_hashes'}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
