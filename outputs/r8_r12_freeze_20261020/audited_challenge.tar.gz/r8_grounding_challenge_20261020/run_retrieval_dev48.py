"""Compare frozen r5/r8 Top-5 synonym retrieval on a fixed development selection."""
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'
sys.path.insert(0, str(ROOT/'local'))
from run_storage import write_json


def read(path):
    return json.loads(path.read_text())


def state(**fields):
    write_json(BASE/'retrieval_dev48_state.json',
               {'time': datetime.now().astimezone().isoformat(), 'pid': os.getpid(), **fields})


def main():
    selection = BASE/'retrieval_dev48_manifest.json'
    selected = read(selection)
    expected = {r['csv_row']: r for r in selected['rows']}
    if len(expected) != 48:
        raise RuntimeError('Expected the fixed 48-query development selection')
    shared = (ROOT/'local_outputs/v74_r8_r5_top5_retry_20261020/.api_slots').resolve()
    if not shared.is_dir():
        raise RuntimeError('The existing full-run API slot directory is required')
    records = {}
    for revision in ('r5', 'r8'):
        source = BASE/f'source_{revision}'
        hashes = read(source/'SOURCE_MANIFEST.json')['code_sha256']
        if any(hashlib.sha256((source/'local'/n).read_bytes()).hexdigest() != h for n, h in hashes.items()):
            raise RuntimeError('Frozen development source changed')
        output = ROOT/'local_outputs'/f'v74_r8_{revision}_retrieval_dev48_20261020'
        output.mkdir(exist_ok=False)
        (output/'.api_slots').symlink_to(shared, target_is_directory=True)
        command = ['bash', str(source/'local/run_local_v9.sh'), '--predictions',
            str(BASE.parent/'r8_grounding_input_20261020/20261020_r8_object_predictions'),
            '--scene-root', str(ROOT/'local_outputs'), '--manifest', str(selection),
            '--category-top-k', '5', '--output', str(output)]
        env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1',
               'SEEGROUND_R8_GROUNDING_REVISION': revision,
               'SEEGROUND_WORKERS': '4', 'SEEGROUND_API_CONCURRENCY': '8'}
        log = BASE/f'{revision}_retrieval_dev48.log'
        with log.open('a') as handle:
            process = subprocess.Popen(command, cwd=source, env=env, stdout=handle, stderr=subprocess.STDOUT)
            state(status='running', revision=revision, child_pid=process.pid,
                  output=str(output), log=str(log), shared_api_slots=str(shared))
            print(f'Started {revision} retrieval development: PID {process.pid}', flush=True)
            code = process.wait()
        if code:
            raise RuntimeError(f'{revision} exited {code}; inspect {log}')
        result = read(output/'results.json')
        manifest = read(output/'manifest.json')
        rows = {r['csv_row']: r for r in result['results']}
        if len(rows) != 48 or set(rows) != set(expected):
            raise RuntimeError('Development run is incomplete')
        if manifest['code_sha256'] != hashes or Path(manifest['api']['api_slot_dir']).resolve() != shared:
            raise RuntimeError('Source or physical API slots differ from the fixed inputs')
        for key, row in rows.items():
            if any(row[k] != expected[key][k] for k in ('scene', 'query', 'target_id')):
                raise RuntimeError('Query identity changed')
            if row['correct'] != (row['predicted_id'] == row['target_id'] and not row.get('error')):
                raise RuntimeError('Incorrect saved evaluation')
            if row.get('error'):
                continue
            pred = read(output/f'q{key:05d}/prediction.json')
            if (pred['predicted_id'] != row['predicted_id']
                    or pred['gt_categories_supplied_to_model'] or pred['query_target_id_supplied_to_model']
                    or (pred['predicted_id'] is not None and pred['predicted_id'] not in pred['category_target_ids'])):
                raise RuntimeError('Final prediction provenance failed')
        records[revision] = {'correct': sum(r['correct'] for r in rows.values()),
            'errors': sum(bool(r.get('error')) for r in rows.values()), 'output': str(output),
            'rows': rows, 'api_attempts': result['summary']['actual_api_attempts']}
        print(json.dumps({revision: {k: v for k, v in records[revision].items() if k != 'rows'}}), flush=True)
    def compare(keys):
        return {'queries': len(keys),
            'r5_correct': sum(records['r5']['rows'][k]['correct'] for k in keys),
            'r8_correct': sum(records['r8']['rows'][k]['correct'] for k in keys),
            'gained': [k for k in keys if not records['r5']['rows'][k]['correct'] and records['r8']['rows'][k]['correct']],
            'lost': [k for k in keys if records['r5']['rows'][k]['correct'] and not records['r8']['rows'][k]['correct']]}
    report = {'created_at': datetime.now().astimezone().isoformat(), 'all': compare(list(expected)),
        'alias_descriptions': compare(selected['focus_csv_rows']),
        'controls': compare(selected['control_csv_rows']),
        'runs': {r: {k: v for k, v in data.items() if k != 'rows'} for r, data in records.items()},
        'paired_source_input_and_saved_finals_checked': True,
        'not_independent_full_accuracy': True, 'selection_policy': selected['selection_policy']}
    write_json(BASE/'retrieval_dev48_comparison.json', report)
    state(status='phases_completed', summary=report, promotion_pending=True, goal_achieved=False)
    print(json.dumps(report, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    if (BASE/'retrieval_dev48_state.json').exists():
        raise SystemExit('Existing retrieval development state: inspect the original job')
    try:
        main()
    except Exception as exc:
        state(status='failed', error=str(exc))
        raise
