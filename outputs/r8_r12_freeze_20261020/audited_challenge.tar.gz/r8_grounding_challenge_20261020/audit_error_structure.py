"""Audit a fixed snapshot of saved final predictions, without launching inference."""
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'
RUN = ROOT/'local_outputs/v74_r8_r3_top1_full_20261020'
sys.path.insert(0, str(BASE/'source_r3/local'))
from evidence import retrieval_category


def read(path):
    return json.loads(path.read_bytes())


def measure(rows):
    count = len(rows)
    correct = sum(r['correct'] for r in rows)
    return {'evaluated': count, 'correct': correct,
            'accuracy_on_snapshot_only': correct/count if count else None,
            'errors': sum(bool(r.get('error')) for r in rows),
            'abstained_without_error': sum(r.get('predicted_id') is None and not r.get('error') for r in rows)}


def inspect(row):
    if row.get('error'):
        return {**row, 'outcome': 'execution_error', 'reference_coverage': 'unknown'}
    p = read(RUN/f"q{row['csv_row']:05d}/prediction.json")
    if p['predicted_id'] != row['predicted_id']:
        raise ValueError(f"Final prediction mismatch at CSV {row['csv_row']}")
    if p['gt_categories_supplied_to_model'] or p['query_target_id_supplied_to_model']:
        raise ValueError('Evaluation labels supplied to inference')
    if row['predicted_id'] is not None and row['predicted_id'] not in p['category_target_ids']:
        raise ValueError('Final ID outside retrieved target IDs')
    trace = p.get('active_trace', {})
    references = trace.get('query_structure', {}).get('reference_categories', [])
    graph = trace.get('query_graph', {})
    if 'reference_bindings' not in graph:
        coverage, missing = 'unknown', []
    else:
        bindings = {retrieval_category(b['category']): b.get('initial_candidate_ids', b['candidate_ids'])
                    for b in graph['reference_bindings']}
        missing = [name for name in references if not bindings.get(retrieval_category(name))]
        coverage = 'some_reference_category_missing' if missing else ('all_reference_categories_matched' if references else 'no_parsed_reference')
    recalled = row.get('category_candidate_recall')
    if row['correct']:
        outcome = 'correct'
    elif recalled is False:
        outcome = 'target_not_recalled'
    elif recalled is True:
        outcome = 'recalled_but_abstained' if row['predicted_id'] is None else 'recalled_but_wrong_id'
    else:
        outcome = 'unknown_target_recall'
    return {**row, 'outcome': outcome, 'reference_coverage': coverage,
            'missing_reference_categories': missing}


def main():
    raw = (RUN/'results.json').read_bytes()
    rows = json.loads(raw)['results']
    canonical = {r['csv_row']: r for r in read(ROOT/'local/validation/nr3d_val_full.json')['rows']}
    if len({r['csv_row'] for r in rows}) != len(rows):
        raise ValueError('Duplicate snapshot query')
    for r in rows:
        if any(r[k] != canonical[r['csv_row']][k] for k in ('scene', 'query', 'target_id', 'easy', 'view_dep')):
            raise ValueError('Snapshot identity differs from canonical selection')
        if r['correct'] != (r['predicted_id'] == r['target_id'] and not r.get('error')):
            raise ValueError('Stored correctness differs from final ID')
    with ThreadPoolExecutor(max_workers=4) as pool:
        audited = list(pool.map(inspect, rows))
    outcomes = Counter(r['outcome'] for r in audited)
    reference_groups = {key: measure([r for r in audited if r['reference_coverage'] == key])
                        for key in sorted({r['reference_coverage'] for r in audited})}
    groups = {key: measure([r for r in audited if bool(r[field]) == value])
              for key, field, value in [('easy', 'easy', True), ('hard', 'easy', False),
                  ('view_dependent', 'view_dep', True), ('view_independent', 'view_dep', False)]}
    gt = {r['csv_row']: r for r in read(ROOT/'local_outputs/v7_4_nr3d_val_full_gt/results.json')['results']}
    matched_gt = []
    for r in audited:
        previous = gt[r['csv_row']]
        if any(previous[k] != r[k] for k in ('scene', 'query', 'target_id')):
            raise ValueError('Historical GT query identity differs')
        matched_gt.append(previous)
    initial = read(BASE.parent/'r8_grounding_audit_20261020/snapshot_evaluations.json')
    initial_by_id = {r['csv_row']: r for r in initial}
    paired = [r for r in audited if r['csv_row'] in initial_by_id]
    report = {'created_at': datetime.now().astimezone().isoformat(), 'run': str(RUN),
        'snapshot_results_sha256': hashlib.sha256(raw).hexdigest(),
        'snapshot_csv_rows': [r['csv_row'] for r in audited], 'full_selection_total': len(canonical),
        'summary': measure(audited), 'outcome_partition': dict(outcomes), 'groups': groups,
        'reference_category_coverage_groups': reference_groups,
        'matched_historical_gt_cumulative': measure(matched_gt),
        'paired_initial_snapshot': {'initial_total': len(initial), 'paired': len(paired),
            'initial_correct': sum(initial_by_id[r['csv_row']]['correct'] for r in paired),
            'r3_correct': sum(r['correct'] for r in paired),
            'gained': [r['csv_row'] for r in paired if r['correct'] and not initial_by_id[r['csv_row']]['correct']],
            'lost': [r['csv_row'] for r in paired if not r['correct'] and initial_by_id[r['csv_row']]['correct']]},
        'inference_gt_flags_checked_for_all_successful_rows': True,
        'limitations': 'Partial, exposed snapshot; reference coverage is parsed-category availability, not physical absence or causal attribution. Historical GT is cumulative, not a paired single-pass ablation.',
        'rows': [{'csv_row': r['csv_row'], 'outcome': r['outcome'], 'reference_coverage': r['reference_coverage'],
                  'missing_reference_categories': r.get('missing_reference_categories', [])} for r in audited]}
    assert sum(outcomes.values()) == len(audited)
    (BASE/'error_structure_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('rows', 'snapshot_csv_rows')}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
