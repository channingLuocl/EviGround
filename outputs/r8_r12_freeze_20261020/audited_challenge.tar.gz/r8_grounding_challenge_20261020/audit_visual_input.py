"""Check image consumption using synthetic digits absent from request text."""
import json
from pathlib import Path
import secrets
import time

from PIL import Image, ImageDraw, ImageFont
from qwen_api import chat, image_part, parse_json_object

BASE = Path(__file__).resolve().parent/'visual_input_control'


def main():
    if (BASE/'results.json').exists():
        raise ValueError('Preserve the existing visual-control results; use a fresh output directory')
    BASE.mkdir(exist_ok=True)
    font = ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial Black.ttf', 120)
    cases = []
    for index in range(4):
        expected = str(1000+secrets.randbelow(9000))
        path = BASE/f'control_{index}.png'
        canvas = Image.new('RGB', (640, 240), 'white')
        ImageDraw.Draw(canvas).text((100, 35), expected, font=font, fill='black')
        canvas.save(path)
        started = time.monotonic()
        try:
            # Identical text for every image; the expected digits are not sent.
            response = chat([{'role': 'system', 'content': 'Read the attached image. Return JSON only.'},
                {'role': 'user', 'content': [
                    {'type': 'text', 'text': 'Read the four large black digits from left to right. Return {"digits":"...."}. If unreadable return {"digits":null}.'},
                    image_part(path)]}], max_tokens=128, json_mode=True)
            predicted = parse_json_object(response['_content']).get('digits')
            case = {'index': index, 'expected_evaluation_only': expected, 'predicted': predicted,
                'correct': str(predicted) == expected, 'response': response['_content'],
                'usage': response.get('usage'), 'request_summary': response.get('_baseline', {}).get('request_summary'),
                'model': response.get('_baseline', {}).get('model'), 'finish_reason': response.get('_finish_reason')}
        except ValueError as exc:
            case = {'index': index, 'expected_evaluation_only': expected, 'correct': False, 'error': str(exc)}
        case['latency_s'] = round(time.monotonic()-started, 3)
        cases.append(case)
        (BASE/'results.json').write_text(json.dumps({'complete': len(cases) == 4,
            'correct': sum(c['correct'] for c in cases), 'cases': cases,
            'note': 'Synthetic image control only. Passing does not establish point-cloud grounding accuracy.'},
            ensure_ascii=False, indent=2)+'\n')
        print(json.dumps(case, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
