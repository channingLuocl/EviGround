"""Compare cumulative final-answer accounting with fully preserved source runs."""
from datetime import datetime
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'


def read(path):
    return json.loads(path.read_bytes())


def main():
    raw = (BASE/'progress_cumulative.json').read_bytes()
    snapshot_digest = hashlib.sha256(raw).hexdigest()
    snapshot_path = BASE/'audit_snapshots'/f'{snapshot_digest}.json'
    snapshot_path.parent.mkdir(exist_ok=True)
    if not snapshot_path.exists():
        snapshot_path.write_bytes(raw)
    cumulative = json.loads(raw)
    canonical = {r['csv_row']: r for r in read(ROOT/'local/validation/nr3d_val_full.json')['rows']}
    audit = BASE.parent/'r8_grounding_audit_20261020'
    sources = [BASE/f'source_r{i}'/'local' for i in range(3, 13)]
    sources += [audit/f'r{i}_source' for i in (1, 2, 3)]
    hashes = {str(p): {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in p.glob('*.py')}
              for p in sources}
    verified, runs = set(), []
    for run in cumulative['single_pass_runs']:
        path = Path(run['run'])/'manifest.json'
        manifest_raw = path.read_bytes()
        if hashlib.sha256(manifest_raw).hexdigest() != run['manifest_sha256']:
            raise ValueError('Run manifest changed after cumulative snapshot')
        manifest = json.loads(manifest_raw)
        if manifest['categories']['source_predictions_sha256'] != cumulative['summary']['source_predictions_sha256']:
            raise ValueError('Prediction export differs between source runs')
        expected = manifest['code_sha256']
        options = [(sum(h.get(k) != v for k, v in expected.items()), source) for source, h in hashes.items()]
        count, closest = min(options)
        if not count:
            verified.add(run['run'])
        runs.append({'run': run['run'], 'version': run['version'], 'evaluated': run['evaluated'],
            'modules_checked': len(expected), 'source_fully_preserved': count == 0,
            'closest_source': closest,
            'missing_or_different_modules': [k for k, v in expected.items() if hashes[closest].get(k) != v]})
    chosen, exclusive = {}, []
    for key, attempts in cumulative['attempt_history'].items():
        i = int(key)
        for row in attempts:
            expected_correct = row['predicted_id'] == canonical[i]['target_id'] and not row.get('error')
            if bool(row['correct']) != expected_correct:
                raise ValueError('Attempt correctness differs from final ID')
            if row['run'] not in verified:
                continue
            if i not in chosen or (not chosen[i]['correct'] and (row['correct'] or not row.get('error'))):
                chosen[i] = row
        if any(r['correct'] for r in attempts) and not chosen.get(i, {}).get('correct'):
            exclusive.append(i)
    def group(predicate):
        ids = [i for i, row in canonical.items() if predicate(row)]
        correct = sum(chosen.get(i, {}).get('correct', False) for i in ids)
        return {'selected': len(ids), 'evaluated': sum(i in chosen for i in ids),
                'correct': correct, 'accuracy_over_full_selected': correct/len(ids)}
    summary = group(lambda r: True)
    report = {'created_at': datetime.now().astimezone().isoformat(),
        'cumulative_snapshot_sha256': snapshot_digest,
        'cumulative_snapshot_path': str(snapshot_path),
        'snapshot_csv_rows': [r['csv_row'] for r in cumulative['results']],
        'all_saved_final_summary': cumulative['summary'], 'source_verified_summary': summary,
        'source_verified_groups': {
            name: group(lambda r, field=field, value=value: r[field] == value)
            for name, field, value in [('easy', 'easy', True), ('hard', 'easy', False),
                ('view_dependent', 'view_dep', True), ('view_independent', 'view_dep', False)]},
        'correct_queries_depending_only_on_unpreserved_source': exclusive,
        'same_correct_count': summary['correct'] == cumulative['summary']['correct'],
        'same_evaluated_coverage': summary['evaluated'] == cumulative['summary']['evaluated'],
        'runs': runs, 'not_a_completion_audit': True,
        'limitations': 'Only source preservation and saved cumulative accounting are audited here. Full coverage, per-query input provenance, remaining API failures and goal attainment require final audit. No inference or original outputs are modified.'}
    (BASE/'source_provenance_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('snapshot_csv_rows', 'runs')}, ensure_ascii=False, indent=2))
    print(json.dumps({'unpreserved_source_runs': [r for r in runs if not r['source_fully_preserved']]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
