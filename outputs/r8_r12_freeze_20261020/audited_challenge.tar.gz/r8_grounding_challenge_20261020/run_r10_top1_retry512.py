"""Fixed-size r10 Top-1 retry; failure selection is an evaluation oracle."""
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'
SOURCE = BASE/'source_r10'
OUTPUT = ROOT/'local_outputs/v74_r8_r10_top1_retry512_20261020'
STATE = BASE/'r10_top1_retry512_state.json'
sys.path.insert(0, str(ROOT/'local'))
from r8_challenge_results import collect, read
from run_storage import write_json
from audit_saved_final_predictions import main as audit_finals


def status(**fields):
    write_json(STATE, {'time': datetime.now().astimezone().isoformat(),
        'pid': os.getpid(), **fields})


def main():
    canonical = read(ROOT/'local/validation/nr3d_val_full.json')
    rows = {r['csv_row']: r for r in canonical['rows']}
    baseline_raw = (BASE/'progress_cumulative.json').read_bytes()
    baseline = json.loads(baseline_raw)
    assert baseline['summary']['complete'] and len(rows) == 7805
    digest = hashlib.sha256(baseline_raw).hexdigest()
    archive = BASE/'audit_snapshots'/f'{digest}.json'
    if not archive.exists():
        archive.write_bytes(baseline_raw)
    assert archive.read_bytes() == baseline_raw
    runs = [Path(r['run']) for r in baseline['single_pass_runs']]
    runs += [ROOT/'local_outputs'/f'v74_r8_{r}_reference_views_dev48_20261020'
             for r in ('r10', 'r11')]
    correct, seen, inputs = set(), set(), []
    for run in runs:
        manifest = read(run/'manifest.json')
        assert manifest['categories']['source_predictions_sha256'] == baseline['summary']['source_predictions_sha256']
        raw = (run/'results.json').read_bytes()
        aggregate = json.loads(raw)
        run_rows = {r['csv_row']: r for r in manifest['rows']}
        ids = set()
        for r in aggregate['results']:
            i = r['csv_row']
            assert i not in ids and i in run_rows and i in rows
            assert all(r.get(k) == rows[i][k] for k in
                ('scene', 'query', 'target_id', 'easy', 'view_dep'))
            final = r.get('predicted_id')
            assert final is None or type(final) is int
            valid = final == rows[i]['target_id'] and not r.get('error')
            assert bool(r['correct']) == bool(valid)
            ids.add(i)
            if valid:
                correct.add(i)
        assert len(ids) == len(aggregate['results'])
        assert aggregate['summary']['correct'] == sum(bool(r['correct']) for r in aggregate['results'])
        seen.update(ids)
        sha = hashlib.sha256(raw).hexdigest()
        fixed = BASE/'audit_snapshots'/f'{sha}.json'
        if not fixed.exists():
            fixed.write_bytes(raw)
        assert fixed.read_bytes() == raw
        inputs.append({'run': str(run.resolve()), 'sha256': sha,
            'snapshot': str(fixed), 'evaluated': len(ids),
            'selected': len(run_rows)})
    assert seen == set(rows)
    assert {r['csv_row'] for r in baseline['results'] if r['correct']} <= correct
    key = lambda i: hashlib.sha256(f'r10-top1-retry512-20261020:{i}'.encode()).hexdigest()
    selected = sorted(sorted(set(rows)-correct, key=key)[:512])
    assert len(selected) == 512
    selection_path = BASE/'r10_top1_retry512_manifest.json'
    write_json(selection_path, {**canonical, 'rows': [rows[i] for i in selected],
        'purpose': 'User-authorized evaluation-oracle cumulative retry, frozen r10 Top-1',
        'selection_policy': 'Fixed SHA256 order of never-correct queries; first 512',
        'baseline_correct': len(correct), 'baseline_snapshot_sha256': digest,
        'aggregate_snapshots': inputs, 'inference_gt_categories': False,
        'answers_sent_to_workers': False, 'not_independent_full_accuracy': True})
    hashes = read(SOURCE/'SOURCE_MANIFEST.json')['code_sha256']
    assert all(hashlib.sha256((SOURCE/'local'/n).read_bytes()).hexdigest() == h
               for n, h in hashes.items())
    shared = (ROOT/'local_outputs/v74_r8_r5_top5_retry_20261020/.api_slots').resolve()
    OUTPUT.mkdir(exist_ok=False)
    (OUTPUT/'.api_slots').symlink_to(shared, target_is_directory=True)
    command = ['bash', str(SOURCE/'local/run_local_v9.sh'), '--predictions',
        str(BASE.parent/'r8_grounding_input_20261020/20261020_r8_object_predictions'),
        '--scene-root', str(ROOT/'local_outputs'), '--manifest', str(selection_path),
        '--category-top-k', '1', '--output', str(OUTPUT)]
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1',
        'SEEGROUND_R8_GROUNDING_REVISION': 'r10',
        'SEEGROUND_WORKERS': '6', 'SEEGROUND_API_CONCURRENCY': '8'}
    log = BASE/'r10_top1_retry512.log'
    with log.open('a') as handle:
        process = subprocess.Popen(command, cwd=SOURCE, env=env,
            stdout=handle, stderr=subprocess.STDOUT)
        status(status='running', revision='r10', category_top_k=1,
            child_pid=process.pid, selected=512, baseline_correct=len(correct),
            source=str(SOURCE), output=str(OUTPUT), log=str(log),
            selection=str(selection_path), shared_api_slots=str(shared))
        print(f'Started fixed r10 Top-1 retry512, baseline {len(correct)}/7805, child PID {process.pid}', flush=True)
        code = process.wait()
    if code:
        raise RuntimeError(f'r10 Top-1 retry exited {code}; inspect {log}')
    manifest = read(OUTPUT/'manifest.json')
    assert manifest['rows'] == read(selection_path)['rows']
    assert manifest['code_sha256'] == hashes
    assert Path(manifest['api']['api_slot_dir']).resolve() == shared
    report = collect(read(selection_path), [OUTPUT])
    assert report['summary']['evaluated'] == 512
    phase = BASE/'r10_top1_retry512_phase_results.json'
    write_json(phase, report)
    status(status='auditing_saved_finals', selected=512, output=str(OUTPUT))
    audit_finals(phase, BASE/'r10_top1_retry512_saved_final_audit.json')
    status(status='phase_completed', selected=512, output=str(OUTPUT),
        summary=report['summary'], all_saved_final_predictions_checked=True,
        full_denominator_union_pending=True, goal_achieved=False)
    print(json.dumps(report['summary'], ensure_ascii=False), flush=True)


if __name__ == '__main__':
    if OUTPUT.exists() or STATE.exists():
        raise SystemExit('Existing retry output/state; inspect the original job')
    try:
        main()
    except Exception as exc:
        status(status='failed', error=str(exc))
        raise
