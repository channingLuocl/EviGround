"""Reference tiles preserve target IDs, prior behavior and existing image files."""
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from r8_grounding import isolated_reference_views, isolated_target_views
from test_r8_grounding import prediction
from v74_grounding import ground_scene


class ReferenceViewTests(unittest.TestCase):
    def setUp(self):
        env = patch.dict(os.environ, {'SEEGROUND_V4': '1', 'SEEGROUND_V7': '1',
            'SEEGROUND_V7_4': '1', 'SEEGROUND_V9': '1', 'SEEGROUND_V9_SOURCE': 'r8',
            'SEEGROUND_R8_GROUNDING_REVISION': 'r11'})
        env.start(); self.addCleanup(env.stop)

    def test_every_reference_is_tiled_without_duplicate_targets(self):
        objects = [prediction(i, ['chair']) for i in range(1, 10)]
        calls = []
        def render(action, pool, xyz, rgb, ids, out, index):
            calls.append((action['focus_ids'], index))
            return {'image': str(out/f'{index}.png'), 'marked_ids': action['focus_ids']}
        with patch('active_diagnostic.render_action', side_effect=render):
            views = isolated_reference_views({'Anchor': ['chair']}, objects, objects[:1],
                np.zeros((1, 3)), np.zeros((1, 3)), np.array([1]), Path('/unused'))
        self.assertEqual(calls, [([2, 3, 4, 5, 6, 7], 2000), ([8, 9], 2001)])
        self.assertTrue(all(v['kind'] == 'isolated_reference_views' for v in views))

    def test_no_retrieved_reference_adds_no_image(self):
        with patch('active_diagnostic.render_action') as render:
            self.assertEqual(isolated_reference_views({'Anchor': ['printer']},
                [prediction(1, ['chair'])], [], None, None, None, Path('/unused')), [])
        render.assert_not_called()

    def test_native_reference_render_does_not_overwrite_target_tiles(self):
        target, reference = prediction(1, ['chair']), prediction(2, ['desk'], xyz=(1, 1, 1))
        xyz = np.array([[0., 0., 0.], [1., 1., 1.]])
        rgb, ids = np.zeros((2, 3)), np.array([1, 2])
        with tempfile.TemporaryDirectory() as directory:
            before = isolated_target_views([target], xyz, rgb, ids, directory)[0]
            digest = hashlib.sha256(Path(before['image']).read_bytes()).hexdigest()
            after = isolated_reference_views({'Anchor': ['desk']}, [target, reference],
                [target], xyz, rgb, ids, directory)[0]
            self.assertNotEqual(before['image'], after['image'])
            self.assertTrue(Path(after['image']).is_file())
            self.assertEqual(after['marked_ids'], [2])
            self.assertEqual(hashlib.sha256(Path(before['image']).read_bytes()).hexdigest(), digest)

    def test_opt_in_adds_reference_evidence_without_expanding_allowed_targets(self):
        query = 'The chair beside the blue desk.'
        objects = [prediction(1, ['chair']), prediction(2, ['desk'], xyz=(1, 1, 1))]
        parsed = {'Target': ['chair'], 'Anchor': ['desk'], '_v4_budget': {}}
        reply = {'_content': json.dumps({'predicted_id': 1, 'reason': 'Compared target and reference',
            'evidence': [{'source_quote': query, 'object_ids': [1, 2], 'observation': 'Observed adjacency'}],
            'unresolved': [], 'numeric_choice': None}), '_finish_reason': 'stop', '_baseline': {}}
        for revision in ('r10', 'r11'):
            trace = {'steps': [], 'backtracks': [], 'internal_usage': {'render': 0, 'visual_check': 0}}
            calls = []
            with patch.dict(os.environ, {'SEEGROUND_R8_GROUNDING_REVISION': revision}), \
                    patch('v74_grounding.scene_views', return_value=[]), \
                    patch('r8_grounding.isolated_target_views', return_value=[]), \
                    patch('r8_grounding.isolated_reference_views', return_value=[{
                        'image': 'reference.png', 'kind': 'isolated_reference_views', 'marked_ids': [2]}]) as refs, \
                    patch('v74_grounding.image_part', return_value={}), \
                    patch('v74_grounding.chat', return_value=reply) as model:
                result = ground_scene(query, parsed, objects, objects[:1], np.zeros((2, 3)),
                    np.zeros((2, 3)), np.array([1, 2]), Path('/unused'), calls, {}, trace)
            payload = json.loads(model.call_args.args[0][1]['content'][0]['text'])
            self.assertEqual(result['predicted_id'], 1)
            self.assertEqual(payload['allowed_target_ids'], [1])
            self.assertEqual(refs.call_count, int(revision == 'r11'))
            self.assertEqual(len(payload['views']), int(revision == 'r11'))
            self.assertEqual([c['stage'] for c in calls], ['v74_scene_grounding'])


if __name__ == '__main__':
    unittest.main()
