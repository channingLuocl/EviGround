"""Measure predicted reference coverage, without claiming reference correctness."""
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'
sys.path.insert(0, str(ROOT/'local'))
from evidence import match_retrieval_categories


def read(path):
    return json.loads(path.read_text())


def main():
    selection = read(BASE/'distance_dev48_manifest.json')['rows']
    export = read(BASE.parent/'r8_grounding_input_20261020/20261020_r8_object_predictions/predictions.json')
    objects = {}
    for row in export['results']:
        objects.setdefault(row['scene'], []).append({'bbox_id': row['bbox_id'],
            'target': row['predicted_object'], 'category_hypotheses': row['top5'], 'bbox_3d': row['bbox_3d']})
    cases = []
    for row in selection:
        directory = ROOT/'local_outputs/v74_r8_r3_top1_full_20261020'/f"q{row['csv_row']:05d}"
        prediction = read(directory/'prediction.json')
        anchors = read(directory/'run.json')['parsed_query'].get('Anchor', [])
        top5 = objects[row['scene']]
        top1 = [{**o, 'category_hypotheses': o['category_hypotheses'][:1]} for o in top5]
        changes = []
        for category in anchors:
            one = match_retrieval_categories([category], top1)
            five = match_retrieval_categories([category], top5)
            if not one and five:
                changes.append({'reference_category': category, 'top5_matched_ids': [o['bbox_id'] for o in five]})
        cases.append({'csv_row': row['csv_row'], 'query': row['query'],
                      'r3_predicted_id': prediction['predicted_id'], 'references_added_by_top5': changes})
    summary = {'queries': len(cases),
        'with_top5_only_reference_category': sum(bool(r['references_added_by_top5']) for r in cases),
        'with_top5_only_reference_and_r3_null': sum(bool(r['references_added_by_top5'])
            and r['r3_predicted_id'] is None for r in cases),
        'note': 'Predicted category match coverage only; reference correctness and grounding benefit unverified.'}
    (BASE/'distance_dev48_reference_coverage.json').write_text(
        json.dumps({'summary': summary, 'cases': cases}, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    main()
