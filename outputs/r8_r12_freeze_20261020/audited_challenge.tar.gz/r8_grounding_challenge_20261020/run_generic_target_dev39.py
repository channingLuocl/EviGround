"""Compare frozen r10/r12 generic-target evidence on one fixed query selection."""
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]/'reproductions/SeeGround'
sys.path.insert(0, str(ROOT/'local'))
from r8_challenge_results import collect, read
from run_storage import write_json
from audit_saved_final_predictions import main as audit_finals


def state(**fields):
    write_json(BASE/'generic_target_dev39_state.json',
        {'time': datetime.now().astimezone().isoformat(), 'pid': os.getpid(), **fields})


def main():
    prior = read(BASE/'retrieval_alias_retry_phase_audit.json')
    if prior['selected'] != 72 or not prior['all_saved_final_predictions_checked']:
        raise RuntimeError('Complete the original alias-retry final-file audit first')
    selection_path = BASE/'generic_target_dev39_manifest.json'
    selection = read(selection_path)
    if len(selection['rows']) != 39:
        raise RuntimeError('Expected the fixed 39-query generic-target selection')
    shared = (ROOT/'local_outputs/v74_r8_r5_top5_retry_20261020/.api_slots').resolve()
    rows, manifests, outputs = {}, {}, []
    for revision in ('r10', 'r12'):
        source = BASE/f'source_{revision}'
        hashes = read(source/'SOURCE_MANIFEST.json')['code_sha256']
        if any(hashlib.sha256((source/'local'/n).read_bytes()).hexdigest() != h for n, h in hashes.items()):
            raise RuntimeError('Frozen development source changed')
        output = ROOT/'local_outputs'/f'v74_r8_{revision}_generic_target_dev39_20261020'
        output.mkdir(exist_ok=False)
        (output/'.api_slots').symlink_to(shared, target_is_directory=True)
        command = ['bash', str(source/'local/run_local_v9.sh'), '--predictions',
            str(BASE.parent/'r8_grounding_input_20261020/20261020_r8_object_predictions'),
            '--scene-root', str(ROOT/'local_outputs'), '--manifest', str(selection_path),
            '--category-top-k', '5', '--output', str(output)]
        env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1',
            'SEEGROUND_R8_GROUNDING_REVISION': revision,
            'SEEGROUND_WORKERS': '4', 'SEEGROUND_API_CONCURRENCY': '8'}
        log = BASE/f'{revision}_generic_target_dev39.log'
        with log.open('a') as handle:
            process = subprocess.Popen(command, cwd=source, env=env, stdout=handle, stderr=subprocess.STDOUT)
            state(status='running', revision=revision, child_pid=process.pid,
                output=str(output), log=str(log), shared_api_slots=str(shared))
            print(f'Started {revision} generic-target development: PID {process.pid}', flush=True)
            code = process.wait()
        if code:
            raise RuntimeError(f'{revision} exited {code}; inspect {log}')
        manifest = read(output/'manifest.json')
        result = read(output/'results.json')
        rows[revision] = {r['csv_row']: r for r in result['results']}
        if (len(rows[revision]) != 39 or manifest['rows'] != selection['rows']
                or manifest['code_sha256'] != hashes
                or Path(manifest['api']['api_slot_dir']).resolve() != shared):
            raise RuntimeError('Selection, source or physical API slots changed')
        manifests[revision] = manifest
        outputs.append(output)
        print(json.dumps({revision: result['summary']}, ensure_ascii=False), flush=True)
    before, after = manifests['r10'], manifests['r12']
    for field in ('rows', 'categories', 'scene_root', 'scene_sha256', 'workers', 'models', 'review_limit'):
        if before[field] != after[field]:
            raise RuntimeError(f'Paired input/settings differ: {field}')
    for field, excluded in [('policy', {'version'}), ('query_syntax', {'implementation_version'}), ('api', {'api_slot_dir'})]:
        if {k: v for k, v in before[field].items() if k not in excluded} != {k: v for k, v in after[field].items() if k not in excluded}:
            raise RuntimeError(f'Paired inference settings differ: {field}')
    changed = sorted(k for k in before['code_sha256'] if before['code_sha256'][k] != after['code_sha256'][k])
    if changed != ['r8_grounding.py', 'r8_precision.py', 'real_scene.py', 'v4_policy.py']:
        raise RuntimeError(f'Unexpected runtime source changes: {changed}')
    snapshot = collect(selection, outputs)
    snapshot_path = BASE/'generic_target_dev39_cumulative.json'
    write_json(snapshot_path, snapshot)
    state(status='auditing_saved_finals', outputs=[str(p) for p in outputs])
    audit_finals(snapshot_path, BASE/'generic_target_dev39_saved_final_audit.json')

    def compare(keys):
        return {'queries': len(keys),
            'r10_correct': sum(rows['r10'][k]['correct'] for k in keys),
            'r12_correct': sum(rows['r12'][k]['correct'] for k in keys),
            'gained': [k for k in keys if not rows['r10'][k]['correct'] and rows['r12'][k]['correct']],
            'lost': [k for k in keys if rows['r10'][k]['correct'] and not rows['r12'][k]['correct']]}

    report = {'created_at': datetime.now().astimezone().isoformat(), 'all': compare(sorted(rows['r10'])),
        'generic_target_descriptions': compare(selection['focus_csv_rows']),
        'controls': compare(selection['control_csv_rows']), 'only_changed_modules': changed,
        'frozen_modules_verified_per_run': len(before['code_sha256']),
        'paired_source_input_models_syntax_api_checked': True,
        'all_saved_final_predictions_checked': True, 'not_independent_full_accuracy': True,
        'errors': {rev: sum(bool(r.get('error')) for r in items.values()) for rev, items in rows.items()},
        'promotion_decision_pending': True}
    write_json(BASE/'generic_target_dev39_comparison.json', report)
    state(status='phases_completed', summary=report, promotion_pending=True, goal_achieved=False)
    print(json.dumps(report, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    if (BASE/'generic_target_dev39_state.json').exists():
        raise SystemExit('Existing generic-target development state: inspect the original job')
    try:
        main()
    except Exception as exc:
        state(status='failed', error=str(exc))
        raise
